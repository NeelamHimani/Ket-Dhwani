package framework;

import java.io.File;
import java.io.FileInputStream;
import java.sql.Driver;
import java.sql.DriverManager;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Random;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;



public class Ketu {

	private WebDriver driver;
	private String Username;
	public static String pwd;
	XSSFSheet DpModulePermission;
	XSSFSheet DpLogin;
	XSSFSheet DpOranization;
	XSSFSheet OrLogin;
	XSSFSheet OrOrganization;
	XSSFSheet DpPatient;
	XSSFSheet OrPatient;
	XSSFSheet DpFaxInbox;
	XSSFSheet DpFaxSend;
	XSSFSheet OrFaxInbox;
	XSSFSheet DpContact;
	XSSFSheet OrContact;
	XSSFSheet OrPayor_tab;
	XSSFSheet DpPayor_tab;
	XSSFSheet DpServicePreferences_tab;
	XSSFSheet OrServicePreferences_tab;
	XSSFSheet DpPrescriptionHistory_tab;
	XSSFSheet OrPrescriptionHistory_tab;
	XSSFSheet DpCaseManagement_tab;
	XSSFSheet OrCaseManagement_tab;
	XSSFSheet DpCommunication_Log;
	XSSFSheet OrCommunication_Log;
	public String shortname;
	public String NCPDP;
	public String NPI;
	public String Rxname;
	Random rand = new Random();
	public int name = rand.nextInt();
	public String ORGRandINT = String.valueOf(name);
	String ORGShortName;
	String LoginValidation;
	boolean CTUser;
	// Create object of SimpleDateFormat class and decide the format fgg
	DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
	// get current date time with Date()
	Date date = new Date();

	// Now format the date fdfdf
	String date1 = dateFormat.format(date);

	static ExtentTest test;
	static ExtentReports report;

	@Test(priority = 0)
	public void readdata() {
		try {
			// Specify the path of file hhjhjh
			File DataPermission = new File("D:\\Neelam_Automation_Work\\project\\5-08-2020\\kloudscript-ondemand-sanity-testng-99bdd1472d7a\\KSAutomation2.0\\DataPermission.xlsx");
			File ObjectRepository = new File("D:\\Neelam_Automation_Work\\project\\5-08-2020\\kloudscript-ondemand-sanity-testng-99bdd1472d7a\\KSAutomation2.0\\ObjectRepository.xlsx");

			String path = System.getProperty("user.dir") + "//Reports//ketu.html";

			report = new ExtentReports(path);

			/*
			 * File DataPermission = new File(
			 * "C:\\Users\\rahulp\\git\\selenium\\KSAutomation2.0\\DataPermission.xlsx");
			 * File ObjectRepository = new File(
			 * "C:\\Users\\rahulp\\git\\selenium\\KSAutomation2.0\\ObjectRepository.xlsx");
			 */
			// load file ff
			FileInputStream datapermissionf = new FileInputStream(DataPermission);
			FileInputStream objectrepositaryf = new FileInputStream(ObjectRepository);

			// Load workbook
			XSSFWorkbook dp = new XSSFWorkbook(datapermissionf);
			XSSFWorkbook or = new XSSFWorkbook(objectrepositaryf);

			// Load sheet- Here we are loading first sheet only
			DpModulePermission = dp.getSheet("Module Permission");
			DpLogin = dp.getSheet("Login");
			DpOranization = dp.getSheet("Organization");
			OrLogin = or.getSheet("Login");
			OrOrganization = or.getSheet("Organization");
			DpPatient = dp.getSheet("Patient");
			OrPatient = or.getSheet("Patient");
			DpFaxInbox = dp.getSheet("FaxInbox");
			DpFaxSend = dp.getSheet("FaxSend");
			OrFaxInbox = or.getSheet("FaxInbox");
			OrContact = or.getSheet("Contact");
			DpContact = dp.getSheet("Contact");
			OrPayor_tab = or.getSheet("Payor_tab");
			DpPayor_tab = dp.getSheet("Payor_tab");
			OrServicePreferences_tab = or.getSheet("Service_Preferencestab");
			DpServicePreferences_tab = dp.getSheet("Service_preferencestab");
			OrPrescriptionHistory_tab = or.getSheet("PrescriptionHistoryTab");
			DpPrescriptionHistory_tab = dp.getSheet("PrescriptionHistoryTab");
			OrCaseManagement_tab = or.getSheet("Case");
			DpCaseManagement_tab = dp.getSheet("Case");
			DpCommunication_Log = dp.getSheet("Communication_Log");
			OrCommunication_Log = or.getSheet("Communication_Log");
			String UserPwd = DpLogin.getRow(1).getCell(2).getStringCellValue();
		//	pwd = StringEncrypt.decrypt(UserPwd);

//			 pwd = StringEncrypt.encrypt(UserPwd);

		} catch (Exception e) {

			System.out.println(e.getMessage());

		}
	}

	@Test(priority = 1)
	public void Login() throws InterruptedException {
		try {

			test = report.startTest("Login with Phamracy User");
			WebDriverWait wait = new WebDriverWait(driver, 15);
			String server = DpModulePermission.getRow(1).getCell(1).getStringCellValue(); // Get the Login

			switch (server) {
			case "Test1":
				driver.get("https://test1.kloudscript.net/kloudscript/auth/login");
//				https://training.kloudscript.net/kloudscript/auth/login
				break;
			case "Test2":
				driver.get("https://test2.kloudscript.net/kloudscript/auth/login");
				break;
			case "Test3":
				driver.get("https://test3.kloudscript.net/kloudscript/auth/login");
				break;
			case "UAT100":
				driver.get("https://uat100.kloudscript.net:100/kloudscript/auth/login");
				break;
			case "UAT251":
				driver.get("https://uat251.kloudscript.net:251/kloudscript/auth/login");
				break;
			case "Ketu":
				driver.get("https://ketu.kloudscript.net/kloudscript/auth/login");
				break;
			case "KsKetu":
				System.out.println("KsKetu");
				break;
			default:
				System.out.println("Not able to Find the Server");
				break;
			}
			String Loginpermission = DpModulePermission.getRow(2).getCell(1).getStringCellValue(); // Get the Login
			test.log(LogStatus.INFO, "Server: " + server); // Permission from
			// excel
			// KS user Login
			if (Loginpermission.equals("KS")) { // Check the Login permission is for which user
				System.out.println("Login with Ks User");

				if (null == DpLogin.getRow(1).getCell(1) || null == DpLogin.getRow(1).getCell(2)) {
					System.out.println("User and Password is Not added");
				} else {
					Username = DpLogin.getRow(1).getCell(1).getStringCellValue();

//					 System.out.println(Username+" : "+UserPwd);
					/*
					 * String usernamehtml = OrLogin.getRow(1).getCell(3).getStringCellValue();
					 * String userpwdhtml = OrLogin.getRow(2).getCell(3).getStringCellValue();
					 */
					String kssohtml = OrLogin.getRow(4).getCell(3).getStringCellValue();
					String emailuserhtml = OrLogin.getRow(6).getCell(3).getStringCellValue();
					String emailuserpwdhtml = OrLogin.getRow(8).getCell(4).getStringCellValue();
					String FirstNexthtml = OrLogin.getRow(7).getCell(3).getStringCellValue();
					String PwdNexthtml = OrLogin.getRow(9).getCell(3).getStringCellValue();

					WebElement KSSO = driver.findElement(By.id(kssohtml));
					((JavascriptExecutor) driver).executeScript("window.scrollTo(0," + KSSO.getLocation().y + ")");
					KSSO.click();
					String winHandleBefore = driver.getWindowHandle();
					for (String winHandle : driver.getWindowHandles()) {
						driver.switchTo().window(winHandle);

					}

					wait.until(ExpectedConditions.visibilityOfElementLocated(By.id(emailuserhtml)));
					// login with ksso user

					WebElement UserEmail = driver.findElement(By.id(emailuserhtml));
					UserEmail.clear();
					UserEmail.sendKeys(Username);

					wait.until(ExpectedConditions.elementToBeClickable(By.id(FirstNexthtml)));
					driver.findElement(By.id(FirstNexthtml)).click();

					wait.until(ExpectedConditions.visibilityOfElementLocated(By.name(emailuserpwdhtml)));

					WebElement UserPass = driver.findElement(By.name(emailuserpwdhtml));
					UserPass.clear();
					UserPass.sendKeys(pwd);

					Thread.sleep(1000);
					wait.until(ExpectedConditions.elementToBeClickable(By.id(PwdNexthtml)));
					driver.findElement(By.id(PwdNexthtml)).click();
					Thread.sleep(4000);
					driver.switchTo().window(winHandleBefore);
					CTUser = false;
				}

			} else {
				// Pharmacy User Login
				System.out.println("Login with Pharmacy User");
				test.log(LogStatus.INFO, "Login with Pharmacy User");

				Username = DpLogin.getRow(2).getCell(1).getStringCellValue();
				String UserPwd = DpLogin.getRow(2).getCell(2).getStringCellValue();
				// System.out.println(Username+" : "+UserPwd);
				String usernamehtml = OrLogin.getRow(1).getCell(3).getStringCellValue();
				String userpwdhtml = OrLogin.getRow(2).getCell(3).getStringCellValue();
				String signinhtml = OrLogin.getRow(3).getCell(3).getStringCellValue();
				// System.out.println(usernamehtml+" : "+userpwdhtml);

				Thread.sleep(2000);

				WebElement userwebelement = driver.findElement(By.id(usernamehtml));
				((JavascriptExecutor) driver)
						.executeScript("window.scrollTo(0," + userwebelement.getLocation().y + ")");
				userwebelement.clear();
				userwebelement.sendKeys(Username);
				WebElement pwdwebelemt = driver.findElement(By.id(userpwdhtml));
				((JavascriptExecutor) driver).executeScript("window.scrollTo(0," + pwdwebelemt.getLocation().y + ")");
				pwdwebelemt.clear();
				pwdwebelemt.sendKeys(UserPwd);

				Thread.sleep(1000);
				driver.findElement(By.id(signinhtml)).click();
				try {
					LoginValidation = driver
							.findElement(By.xpath("/html/body/div[1]/section/section/section/div/div[2]/div"))
							.getText();
					System.out.println(LoginValidation);
				} catch (Exception e) {
					// TODO: handle exception
					e.getMessage();
				}
				String PageTitle = driver.getTitle();
				try {

					if (PageTitle.equalsIgnoreCase("Select Pharmacy Location")) {
						Thread.sleep(2000);
						driver.findElement(By.xpath("/html/body/section/form/div/div[2]/div[1]/button/span[1]"))
								.click();// click
											// on
											// Store
											// dropdown
						Thread.sleep(2000);
						driver.findElement(By.xpath("/html/body/section/form/div/div[2]/div[1]/input"))
								.sendKeys(Keys.DOWN); // Click
														// on
														// First
														// Option
						driver.findElement(By.xpath("/html/body/section/form/div/div[2]/div[1]/input"))
								.sendKeys(Keys.ENTER); // Click on First Option
						driver.findElement(By.xpath("/html/body/section/form/div/div[2]/div[2]/input")).click(); // Click
																													// on
																													// Proceed
																													// Button
					} else {

					}
				} catch (Exception e) {
					// TODO: handle exception
					e.getMessage();
				}
				CTUser = true;

			}
		} catch (Exception e) {
			// TODO: handle exception
			e.getMessage();
		}
		// System.out.println("The Script is Done");

	}

	@Test(priority = 2)
	public void AddHQLocation() {

		try {

			Thread.sleep(4000);
			String HomePageTitle = driver.getTitle();
			Thread.sleep(2000);
			if (HomePageTitle.equals("KloudScript")) { // Check the Page title if we are reach at home page or not.

				WebDriverWait wait = new WebDriverWait(driver, 15);
				Thread.sleep(4000);
				int i = 0;
				while (i < 1) {
					Thread.sleep(2000);
					if (driver.findElement(By.xpath("//*[@id=\'notificationDialogCloseButton\']")).isDisplayed()) {
						driver.findElement(By.xpath("//*[@id=\'notificationDialogCloseButton\']")).click();
					} else {
						i = 1;
					}
				}

				if (CTUser == false) {
					// System.out.println("Here Come true");
					String Organizationpermission = DpModulePermission.getRow(3).getCell(1).getStringCellValue();
					// System.out.println(Organizationpermission);

					if (Organizationpermission.equals("YES")) { // Check the Organization permission
						Thread.sleep(2000);
						String OrgSearchOnHomehtml = OrOrganization.getRow(16).getCell(3).getStringCellValue();
						// System.out.println("Come here");
						String OrgOrgOnHomehtml = OrOrganization.getRow(17).getCell(3).getStringCellValue();
						// System.out.println(OrgSearchOnHomehtml + OrgOrgOnHomehtml);

						WebElement addorgonhomeelement = driver.findElement(By.xpath(OrgSearchOnHomehtml));

						wait.until(ExpectedConditions.elementToBeClickable(By.xpath(OrgSearchOnHomehtml)));
						addorgonhomeelement.click();

						Thread.sleep(4000);

						driver.findElement(By.xpath(OrgOrgOnHomehtml)).click();

						String Addpharmacyhqpermission = DpOranization.getRow(1).getCell(1).getStringCellValue();
						Thread.sleep(2000);
						// Add Pharmacy Headquarter
						if (Addpharmacyhqpermission.equals("YES")) { // Check the Add Pharmacy Headquarter Permission

							// Getting all HTML Element From Excel
							String Orgnamehtml = OrOrganization.getRow(3).getCell(3).getStringCellValue();
							String Orgtypehtml = OrOrganization.getRow(4).getCell(3).getStringCellValue();
							String Orgtypelocationhtml = OrOrganization.getRow(5).getCell(3).getStringCellValue();
							String Orgstatushtml = OrOrganization.getRow(6).getCell(3).getStringCellValue();
							String Orgdispensinghtml = OrOrganization.getRow(62).getCell(3).getStringCellValue();
							String Orgdispensingsearchhtml = OrOrganization.getRow(63).getCell(3).getStringCellValue();
							String Orgclaimswitchhtml = OrOrganization.getRow(64).getCell(3).getStringCellValue();
							String Orgclaimswitchsearchhtml = OrOrganization.getRow(65).getCell(3).getStringCellValue();
							String OrgSavehtml = OrOrganization.getRow(15).getCell(3).getStringCellValue();
							String OrgProfiletabhtml = OrOrganization.getRow(13).getCell(3).getStringCellValue();
							String OrgTimezonehtml = OrOrganization.getRow(14).getCell(3).getStringCellValue();
							String OrgImeplementationhtml = OrOrganization.getRow(11).getCell(3).getStringCellValue();
							String OrgCancel = OrOrganization.getRow(61).getCell(3).getStringCellValue();
							String OrdaddOnmanagementhtml = OrOrganization.getRow(2).getCell(6).getStringCellValue();
							String OrServiceModelhtml = OrOrganization.getRow(68).getCell(3).getStringCellValue();

							// Getting Data From Excel Sheet
							String Orghqname = DpOranization.getRow(31).getCell(3).getStringCellValue();
							String Orghqstatus = DpOranization.getRow(32).getCell(3).getStringCellValue();
							String OrghqDispensing = DpOranization.getRow(33).getCell(3).getStringCellValue();
							String OrghqClaimswitch = DpOranization.getRow(34).getCell(3).getStringCellValue();
							String OrghqImplementation = DpOranization.getRow(35).getCell(3).getStringCellValue();
							String OrghqTimezone = DpOranization.getRow(36).getCell(3).getStringCellValue();
							String OrghqServiceModel = DpOranization.getRow(37).getCell(3).getStringCellValue();

							// System.out.println( Orghqname + Orghqstatus + OrghqDispensing +
							// OrghqClaimswitch + OrghqImplementation + OrghqTimezone + OrghqServiceModel);

							WebElement OrdaddOnmanagemen = driver.findElement(By.className(OrdaddOnmanagementhtml));
							wait.until(ExpectedConditions
									.visibilityOfElementLocated(By.className(OrdaddOnmanagementhtml)));
							OrdaddOnmanagemen.click();

							WebElement Orgnameelement = driver.findElement(By.xpath(Orgnamehtml));
							wait.until(ExpectedConditions.elementToBeClickable(By.xpath(Orgnamehtml)));
							Orgnameelement.clear();
							Orgnameelement.sendKeys(Orghqname);

							Select typoforg = new Select(driver.findElement(By.xpath(Orgtypehtml)));
							typoforg.selectByValue("4");

							Thread.sleep(3000);
							wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(Orgtypelocationhtml)));
							Select typofloc = new Select(driver.findElement(By.xpath(Orgtypelocationhtml)));
							typofloc.selectByValue("1");

							Thread.sleep(2000);
							wait.until(ExpectedConditions.elementToBeClickable(By.xpath(Orgstatushtml)));
							Select orgstatus = new Select(driver.findElement(By.xpath(Orgstatushtml)));
							orgstatus.selectByVisibleText(Orghqstatus);

							Thread.sleep(2000);
							wait.until(ExpectedConditions.elementToBeClickable(By.xpath(Orgdispensinghtml)));
							WebElement DpsElement = driver.findElement(By.xpath(Orgdispensinghtml));
							DpsElement.click();

							Thread.sleep(2000);
							wait.until(ExpectedConditions.elementToBeClickable(By.xpath(Orgdispensingsearchhtml)));
							WebElement DpsSearchElement = driver.findElement(By.xpath(Orgdispensingsearchhtml));
							DpsSearchElement.clear();
							DpsSearchElement.sendKeys(OrghqDispensing);

							Thread.sleep(2000);
							wait.until(ExpectedConditions.elementToBeClickable(
									By.xpath("//*[@id=\'Dispensing-SystemtooltipDiv\']/ul/li[2]/label")));
							driver.findElement(By.xpath("//*[@id=\'Dispensing-SystemtooltipDiv\']/ul/li[2]/label"))
									.click();
							Thread.sleep(2000);
							try {
								driver.findElement(By.xpath("//*[@id=\'Dispensing-SystemtooltipDiv\']/ul/li[2]/label"))
										.sendKeys(Keys.TAB);
							} catch (Exception e) {
								// TODO: handle exception

							}
							wait.until(ExpectedConditions.elementToBeClickable(By.xpath(Orgclaimswitchhtml)));
							WebElement ClaimElement = driver.findElement(By.xpath(Orgclaimswitchhtml));
							ClaimElement.sendKeys(Keys.ENTER);
							// DpsElement.click();

							Thread.sleep(2000);
							wait.until(ExpectedConditions.elementToBeClickable(By.xpath(Orgclaimswitchsearchhtml)));

							WebElement ClaimSearchElement = driver.findElement(By.xpath(Orgclaimswitchsearchhtml));
							ClaimSearchElement.click();
							ClaimSearchElement.sendKeys(OrghqClaimswitch);
							Thread.sleep(1000);
							driver.findElement(By.xpath("//*[text()='" + OrghqClaimswitch + "']")).click();

							Thread.sleep(2000);
							// driver.findElement(By.xpath("//*[@id=\'Claim-SwitchbtnMultiselectDropdown\']")).click();

							Thread.sleep(1000);
							WebElement Implementationelement = driver.findElement(By.xpath(OrgImeplementationhtml));
							Implementationelement.clear();
							Implementationelement.sendKeys(OrghqImplementation);

							Select ServiceModel = new Select(driver.findElement(By.xpath(OrServiceModelhtml)));
							ServiceModel.selectByVisibleText(OrghqServiceModel);

							driver.findElement(By.xpath("//*[@id='isTestData']")).sendKeys(Keys.TAB);

							Thread.sleep(1000);
							WebElement profiletabelement = driver.findElement(By.xpath(OrgProfiletabhtml));
							((JavascriptExecutor) driver)
									.executeScript("window.scrollTo(0," + profiletabelement.getLocation().y + ")");
							profiletabelement.sendKeys(Keys.ENTER);

							Thread.sleep(2000);
							Select timezoneelement = new Select(driver.findElement(By.xpath(OrgTimezonehtml)));
							timezoneelement.selectByValue(OrghqTimezone);

							Thread.sleep(2000);
							WebElement savehqelement = driver.findElement(By.xpath(OrgSavehtml));
							((JavascriptExecutor) driver)
									.executeScript("window.scrollTo(0," + savehqelement.getLocation().y + ")");
							savehqelement.click();

							Thread.sleep(4000);

							if (driver.getTitle().equals("Add Organization")) {

//								System.out.println(driver.findElement(By.xpath("/html/body/section/ul/li")).getText());
								try {
									driver.findElement(
											By.xpath("//*[@id=\"duplicateOrgWarningModal\"]/div/div/div[3]/button[1]"))
											.click();
								} catch (Exception e) {
									// TODO: handle exception
									System.out.println("Added");
								}

								Thread.sleep(3000);

								try {
									WebElement Cancel = driver.findElement(By.xpath(OrgCancel));
									Cancel.click();

								} catch (Exception e) {
									// TODO: handle exception
									System.out.println("Pharmacy HQ is Organization is Added");
								}

							} else {
								System.out.println("Pharmacy HQ is Organization is Added");
							}

						} else {
							System.out.println("Add Pharmacy HQ permission is NO");
						}

						Thread.sleep(4000);
						String HomeHtml = OrOrganization.getRow(66).getCell(3).getStringCellValue();
						WebElement Home = driver.findElement(By.xpath(HomeHtml));
						((JavascriptExecutor) driver).executeScript("window.scrollTo(0," + Home.getLocation().y + ")");
						Home.click();
					} else {
						System.out.println("Add HQ Organization Permission is NO");
						test.log(LogStatus.INFO, "Login with Pharmacy User");
					}

				} else {
					System.out.println("CT User can not access to HQ Organization");
					test.log(LogStatus.INFO, "CT User can not access to HQ Organization");
				}

			} else {
				System.out.println("Login is not done");
			}
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println("Pharmacy HQ is Organization is Added");
			System.out.println(e.getMessage());
		}
	}

	@Test(priority = 3)
	public void AddRXLocation() {
		try {
			Thread.sleep(4000);
			String HomePageTitle = driver.getTitle();
			Thread.sleep(2000);
			if (HomePageTitle.equals("KloudScript")) { // Check the Page title if we are reach at home page or not.

				WebDriverWait wait = new WebDriverWait(driver, 15);
				Thread.sleep(4000);
				int i = 0;
				while (i < 1) {
					Thread.sleep(2000);
					if (driver.findElement(By.xpath("//*[@id=\'notificationDialogCloseButton\']")).isDisplayed()) {
						driver.findElement(By.xpath("//*[@id=\'notificationDialogCloseButton\']")).click();
					} else {
						i = 1;
					}
				}
				if (CTUser == false) {
					// System.out.println("Here Come true");
					String Organizationpermission = DpModulePermission.getRow(3).getCell(1).getStringCellValue();
					// System.out.println(Organizationpermission);

					if (Organizationpermission.equals("YES")) { // Check the Organization permission
						Thread.sleep(2000);
						String OrgSearchOnHomehtml = OrOrganization.getRow(16).getCell(3).getStringCellValue();
						// System.out.println("Come here");
						String OrgOrgOnHomehtml = OrOrganization.getRow(17).getCell(3).getStringCellValue();
						// System.out.println(OrgSearchOnHomehtml + OrgOrgOnHomehtml);

						WebElement addorgonhomeelement = driver.findElement(By.xpath(OrgSearchOnHomehtml));

						wait.until(ExpectedConditions.elementToBeClickable(By.xpath(OrgSearchOnHomehtml)));
						addorgonhomeelement.click();

						Thread.sleep(4000);

						driver.findElement(By.xpath(OrgOrgOnHomehtml)).click();

						String Addpharmacyrxpermission = DpOranization.getRow(2).getCell(1).getStringCellValue();
						// Add Pharmacy RxLocation
						if (Addpharmacyrxpermission.equals("YES")) { // Check the Add Pharmacy RxLocation

							String OrdaddOnmanagementhtml = OrOrganization.getRow(2).getCell(6).getStringCellValue();
							Thread.sleep(2000);
							WebElement OrdaddOnmanagemen = driver.findElement(By.className(OrdaddOnmanagementhtml));
							wait.until(ExpectedConditions
									.visibilityOfElementLocated(By.className(OrdaddOnmanagementhtml)));
							OrdaddOnmanagemen.click();
							// Getting all HTML Element From Excel
							String Orgnamehtml = OrOrganization.getRow(3).getCell(3).getStringCellValue();
							String Orgtypehtml = OrOrganization.getRow(4).getCell(3).getStringCellValue();
							String Orgtypelocationhtml = OrOrganization.getRow(5).getCell(3).getStringCellValue();
							String Orgksclienthtml = OrOrganization.getRow(18).getCell(3).getStringCellValue();
							String Orgstatushtml = OrOrganization.getRow(6).getCell(3).getStringCellValue();
							String Orgshortnamehtml = OrOrganization.getRow(19).getCell(3).getStringCellValue();
							String Orgmanagelicensehtml = OrOrganization.getRow(20).getCell(3).getStringCellValue();
							String OrgLicenseFirsttypehtml = OrOrganization.getRow(21).getCell(3).getStringCellValue();
							String OrgLicenseFirstnumberhtml = OrOrganization.getRow(22).getCell(3).getStringCellValue();
							String OrgLicenseSecondtypehtml = OrOrganization.getRow(24).getCell(3).getStringCellValue();
							String OrgLicenseSecondnumberhtml = OrOrganization.getRow(25).getCell(3).getStringCellValue();
							String OrgAddLicenselinkhtml = OrOrganization.getRow(23).getCell(3).getStringCellValue();
							String OrgSavehtml = OrOrganization.getRow(15).getCell(3).getStringCellValue();

							// Getting Data From Excel Sheet
							String Orgname = DpOranization.getRow(31).getCell(7).getStringCellValue();
							String KSClient = DpOranization.getRow(32).getCell(7).getStringCellValue();
							String Status = DpOranization.getRow(33).getCell(7).getStringCellValue();
							String Shrtname = DpOranization.getRow(34).getCell(7).getStringCellValue();
							String NCPDPNO = DpOranization.getRow(35).getCell(7).getStringCellValue();
							String NPINO = DpOranization.getRow(36).getCell(7).getStringCellValue();
							ORGShortName = Shrtname + ORGRandINT;

							wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(Orgnamehtml)));
							WebElement Orgnameelement = driver.findElement(By.xpath(Orgnamehtml));

							((JavascriptExecutor) driver)
									.executeScript("window.scrollTo(0," + Orgnameelement.getLocation().y + ")");
							Orgnameelement.clear();
							Orgnameelement.sendKeys(Orgname);

							wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(Orgtypehtml)));
							Select TypeofOrgelemenet = new Select(driver.findElement(By.xpath(Orgtypehtml))); // Select
																												// organization
																												// Type
							TypeofOrgelemenet.selectByValue("4");

							wait.until(ExpectedConditions.elementToBeClickable(By.xpath(Orgtypelocationhtml)));
							Select TypeOfLocationelement = new Select(
									driver.findElement(By.xpath(Orgtypelocationhtml))); // Select
																						// location
																						// type
							Thread.sleep(2000);
							TypeOfLocationelement.selectByVisibleText("Rx Location");

							wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(Orgksclienthtml)));
							Select KSclientelement = new Select(driver.findElement(By.xpath(Orgksclienthtml))); // Select
																												// KSclient
							Thread.sleep(2000);
							KSclientelement.selectByValue(KSClient);

							wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(Orgstatushtml)));
							Select OrgStatuselement = new Select(driver.findElement(By.xpath(Orgstatushtml))); // Select
																												// Org
																												// status
							Thread.sleep(2000);
							OrgStatuselement.selectByVisibleText(Status);

							wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(Orgshortnamehtml)));
							WebElement ShrtNameelement = driver.findElement(By.xpath(Orgshortnamehtml)); // Organization
																											// Name
							((JavascriptExecutor) driver)
									.executeScript("window.scrollTo(0," + ShrtNameelement.getLocation().y + ")");
							ShrtNameelement.clear();
							ShrtNameelement.sendKeys(ORGShortName);

							wait.until(ExpectedConditions.elementToBeClickable(By.xpath(Orgmanagelicensehtml))); // Organization
																													// License
							driver.findElement(By.xpath(Orgmanagelicensehtml)).click(); // Click on license Tab

							wait.until(
									ExpectedConditions.visibilityOfElementLocated(By.xpath(OrgLicenseFirsttypehtml)));
							Select OrgNCPDPelement = new Select(driver.findElement(By.xpath(OrgLicenseFirsttypehtml))); // Select
																														// NCDP
																														// First
																														// License
							Thread.sleep(2000);
							OrgNCPDPelement.selectByValue("6");

							wait.until(
									ExpectedConditions.visibilityOfElementLocated(By.xpath(OrgLicenseFirstnumberhtml)));
							WebElement OrgNCPDPNOelemenet = driver.findElement(By.xpath(OrgLicenseFirstnumberhtml)); // Organization
																														// First
																														// License
																														// Number
							((JavascriptExecutor) driver)
									.executeScript("window.scrollTo(0," + OrgNCPDPNOelemenet.getLocation().y + ")");
							OrgNCPDPNOelemenet.clear();
							OrgNCPDPNOelemenet.sendKeys(NCPDPNO);

							wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(OrgAddLicenselinkhtml)));
							driver.findElement(By.xpath(OrgAddLicenselinkhtml)).click(); // Add new License

							wait.until(
									ExpectedConditions.visibilityOfElementLocated(By.xpath(OrgLicenseSecondtypehtml)));
							Select OrgNPIelement = new Select(driver.findElement(By.xpath(OrgLicenseSecondtypehtml))); // Second
																														// License
																														// Type
							Thread.sleep(2000);
							OrgNPIelement.selectByValue("2");

							wait.until(ExpectedConditions
									.visibilityOfElementLocated(By.xpath(OrgLicenseSecondnumberhtml)));
							WebElement OrgNPINOelemenet = driver.findElement(By.xpath(OrgLicenseSecondnumberhtml)); // Second
																													// License
																													// Numner
							((JavascriptExecutor) driver)
									.executeScript("window.scrollTo(0," + OrgNPINOelemenet.getLocation().y + ")");
							OrgNPINOelemenet.clear();
							OrgNPINOelemenet.sendKeys(NPINO);

							wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(OrgSavehtml)));
							WebElement OrgSaveelement = driver.findElement(By.xpath(OrgSavehtml)); // Organization Save
							((JavascriptExecutor) driver)
									.executeScript("window.scrollTo(0," + OrgSaveelement.getLocation().y + ")");
							OrgSaveelement.click();
							Thread.sleep(4000);
							try {

								driver.findElement(
										By.xpath("//*[@id=\"duplicateOrgWarningModal\"]/div/div/div[3]/button[1]"))
										.click();
								System.out.println("Pharmacy Rx "
										+ driver.findElement(By.xpath("/html/body/section/div[1]")).getText());

							} catch (Exception e) {
								// TODO: handle exception
								// System.out.println(e.getMessage());
								System.out.println("Pharmacy Rx "
										+ driver.findElement(By.xpath("/html/body/section/div[1]")).getText());
							}
						} else {
							System.out.println("Pharmacy Rx permission is No");
						}

						Thread.sleep(4000);
						String HomeHtml = OrOrganization.getRow(66).getCell(3).getStringCellValue();
						WebElement Home = driver.findElement(By.xpath(HomeHtml));
						((JavascriptExecutor) driver).executeScript("window.scrollTo(0," + Home.getLocation().y + ")");
						Home.click();
					} else {
						System.out.println("Add Rx Organization Permission is NO");
					}

				} else {
					System.out.println("CT User can not access to RX Organization");
					test.log(LogStatus.INFO, "CT User can not access to RX Organization");

				}

			} else {
				System.out.println("Login is not done");
			}
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println("Organization is not Working");
			System.out.println(e.getMessage());
		}
	}

	@Test(priority = 4)
	public void PrescriberOrganization() {

		test = report.startTest("Prescriber Organization");
		try {
			Thread.sleep(4000);
			String HomePageTitle = driver.getTitle();
			Thread.sleep(2000);
			if (HomePageTitle.equals("KloudScript")) { // Check the Page title if we are reach at home page or not.

				WebDriverWait wait = new WebDriverWait(driver, 15);
				Thread.sleep(4000);
				int i = 0;
				while (i < 1) {
					Thread.sleep(2000);
					if (driver.findElement(By.xpath("//*[@id=\'notificationDialogCloseButton\']")).isDisplayed()) {
						driver.findElement(By.xpath("//*[@id=\'notificationDialogCloseButton\']")).click();
					} else {
						i = 1;
					}
				}
				String Organizationpermission = DpModulePermission.getRow(3).getCell(1).getStringCellValue();

				if (Organizationpermission.equals("YES")) { // Check the Organization permission
					Thread.sleep(2000);
					String OrgSearchOnHomehtml = OrOrganization.getRow(16).getCell(3).getStringCellValue();
					// System.out.println("Come here");
					String OrgOrgOnHomehtml = OrOrganization.getRow(17).getCell(3).getStringCellValue();
					// System.out.println(OrgSearchOnHomehtml + OrgOrgOnHomehtml);

					WebElement addorgonhomeelement = driver.findElement(By.xpath(OrgSearchOnHomehtml));

					wait.until(ExpectedConditions.elementToBeClickable(By.xpath(OrgSearchOnHomehtml)));
					addorgonhomeelement.click();

					Thread.sleep(4000);

					driver.findElement(By.xpath(OrgOrgOnHomehtml)).click();

					String Addprescriberpermainmission = DpOranization.getRow(7).getCell(1).getStringCellValue();
					Thread.sleep(2000);
					// Add Prescriber Main
					if (Addprescriberpermainmission.equals("YES")) { // Check the Add Prescriber Main Permission

						// Getting all HTML Element From Excel
						String Orgnamehtml = OrOrganization.getRow(3).getCell(3).getStringCellValue();
						String Orgtypehtml = OrOrganization.getRow(4).getCell(3).getStringCellValue();
						String Orgtypelocationhtml = OrOrganization.getRow(5).getCell(3).getStringCellValue();
						String Orgksclienthtml = OrOrganization.getRow(18).getCell(3).getStringCellValue();
						String Orgstatushtml = OrOrganization.getRow(6).getCell(3).getStringCellValue();
						String Orgspecialtyhtml = OrOrganization.getRow(12).getCell(3).getStringCellValue();
						String OrgSpecialtyAddhtml = OrOrganization.getRow(67).getCell(3).getStringCellValue();
						String OrgSavehtml = OrOrganization.getRow(15).getCell(3).getStringCellValue();
						String OrgCancel = OrOrganization.getRow(61).getCell(3).getStringCellValue();
						String OrdaddOnmanagementhtml = OrOrganization.getRow(2).getCell(6).getStringCellValue();

						// Getting Data From Excel Sheet
						String Orgmnname = DpOranization.getRow(31).getCell(11).getStringCellValue();
						String KSClient = DpOranization.getRow(32).getCell(11).getStringCellValue();
						String Orgmnstatus = DpOranization.getRow(33).getCell(11).getStringCellValue();
						String Specialty = DpOranization.getRow(34).getCell(11).getStringCellValue();

						WebElement OrdaddOnmanagemen = driver.findElement(By.className(OrdaddOnmanagementhtml));
						wait.until(ExpectedConditions.visibilityOfElementLocated(By.className(OrdaddOnmanagementhtml)));
						OrdaddOnmanagemen.click();

						WebElement Orgnameelement = driver.findElement(By.xpath(Orgnamehtml));
						wait.until(ExpectedConditions.elementToBeClickable(By.xpath(Orgnamehtml)));
						Orgnameelement.clear();
						Orgnameelement.sendKeys(Orgmnname);

						Select typoforg = new Select(driver.findElement(By.xpath(Orgtypehtml)));
						typoforg.selectByValue("5");

						Thread.sleep(2000);
						wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(Orgtypelocationhtml)));

						Select typofloc = new Select(driver.findElement(By.xpath(Orgtypelocationhtml)));
						typofloc.selectByValue("8");

						Thread.sleep(2000);
						typofloc.selectByVisibleText("Main Practice");

						if (CTUser == false) {

							wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(Orgksclienthtml)));
							Select KSclientelement = new Select(driver.findElement(By.xpath(Orgksclienthtml)));
							Thread.sleep(2000);
							KSclientelement.selectByValue(KSClient);
						} else {

						}

						Thread.sleep(2000);
						wait.until(ExpectedConditions.elementToBeClickable(By.xpath(Orgstatushtml)));
						Select orgstatus = new Select(driver.findElement(By.xpath(Orgstatushtml)));
						orgstatus.selectByVisibleText(Orgmnstatus);

						Thread.sleep(3000);

						WebElement Specialtyelement = driver.findElement(By.xpath(Orgspecialtyhtml));
						// Click the Specialty dropdown
						wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(Orgspecialtyhtml)));
						Specialtyelement.click();

						try {
							Thread.sleep(2000);

							ArrayList<WebElement> Spec = (ArrayList<WebElement>) driver.findElements(By.tagName("a")); // Select
																														// dynamic
																														// value
																														// from
																														// Specialty
																														// dropdown
							Thread.sleep(2000);
							for (WebElement SubSpec : Spec) {

								if (SubSpec.getText().equalsIgnoreCase(Specialty)) {

									Thread.sleep(2000);
									SubSpec.click(); // click the desired option
									break;
								}
							}
						} catch (InterruptedException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}

						Thread.sleep(3000);
						WebElement SpecialtyAddelement = driver.findElement(By.xpath(OrgSpecialtyAddhtml));
						// Click the Specialty Add button
						SpecialtyAddelement.click();

						Thread.sleep(2000);
						WebElement savemnelement = driver.findElement(By.xpath(OrgSavehtml));
						((JavascriptExecutor) driver)
								.executeScript("window.scrollTo(0," + savemnelement.getLocation().y + ")");
						savemnelement.click();
						Thread.sleep(4000);
						try {

							driver.findElement(
									By.xpath("//*[@id=\"duplicateOrgWarningModal\"]/div/div/div[3]/button[1]")).click();
							System.out.println("Prescriber "
									+ driver.findElement(By.xpath("/html/body/section/div[1]")).getText());

						} catch (Exception e) {
							// TODO: handle exception
							// System.out.println(e.getMessage());
							System.out.println("Prescriber "
									+ driver.findElement(By.xpath("/html/body/section/div[1]")).getText());
						}

						if (driver.getTitle().equals("Add Organization")) {
							System.out.println(driver.findElement(By.xpath("/html/body/section/ul/li")).getText());
							System.out.println("Main Not added");
							Thread.sleep(2000);
							WebElement Cancel = driver.findElement(By.xpath(OrgCancel));
							Cancel.click();
						} else {
							System.out.println("Prescriber Organization Added Successfully");
							test.log(LogStatus.INFO, "Prescriber Organization Added Successfully");
						}

					} else {
						System.out.println("Add Prescriber Main permission is NO");
					}

					Thread.sleep(4000);
					String HomeHtml = OrOrganization.getRow(66).getCell(3).getStringCellValue();
					WebElement Home = driver.findElement(By.xpath(HomeHtml));
					((JavascriptExecutor) driver).executeScript("window.scrollTo(0," + Home.getLocation().y + ")");
					Home.click();
				} else {
					System.out.println("Add Prescriber Organization Permission is NO");
					test.log(LogStatus.INFO, "Add Prescriber Organization Permission is NO");
				}

			} else {
				System.out.println("Login is not done");
			}
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println("Organization is not Working");
			System.out.println(e.getMessage());
		}
	}

	@Test(priority = 5)
	public void PrescriberContact() throws InterruptedException {

		test = report.startTest("Prescriber Contact");
		try {
			Thread.sleep(4000);
			String HomePageTitle = driver.getTitle();
			if (HomePageTitle.equals("KloudScript")) { // Check the Page title if we are reach at home page or not.

				WebDriverWait wait = new WebDriverWait(driver, 15);
				Thread.sleep(4000);
				int i = 0;
				while (i < 1) {
					Thread.sleep(2000);
					if (driver.findElement(By.xpath("//*[@id=\'notificationDialogCloseButton\']")).isDisplayed()) {
						driver.findElement(By.xpath("//*[@id=\'notificationDialogCloseButton\']")).click();
					} else {
						i = 1;
					}
				}

				String Contactpermission = DpModulePermission.getRow(4).getCell(1).getStringCellValue();
				// System.out.println(Contact permission);

				Thread.sleep(2000);

				if (Contactpermission.equals("YES")) { // Check the Contact permission

					String CRMSearchOnHomehtml = OrContact.getRow(83).getCell(6).getStringCellValue();
					// System.out.println("Come here");
					String ContactsearchOnHomehtml = OrContact.getRow(58).getCell(6).getStringCellValue();
					// System.out.println(ContactSearchOnHomehtml + ContactOnHomehtml);

					WebElement contacthomeelement = driver.findElement(By.className(CRMSearchOnHomehtml));
					wait.until(ExpectedConditions.elementToBeClickable(By.className(CRMSearchOnHomehtml)));
					contacthomeelement.click();

					Thread.sleep(4000);
					driver.findElement(By.className(ContactsearchOnHomehtml)).click();

					// Getting all HTML Element From Object repository
					String Orgtypehtml = OrContact.getRow(2).getCell(3).getStringCellValue();
					String KSClienthtml = OrContact.getRow(3).getCell(3).getStringCellValue();
					String Organizationhtml = OrContact.getRow(4).getCell(3).getStringCellValue();
					String Firstnamehtml = OrContact.getRow(6).getCell(4).getStringCellValue();
					String Middlenamehtml = OrContact.getRow(7).getCell(4).getStringCellValue();
					String Lastnamehtml = OrContact.getRow(8).getCell(4).getStringCellValue();
					String Titlehtml = OrContact.getRow(10).getCell(3).getStringCellValue();
					String Statushtml = OrContact.getRow(11).getCell(4).getStringCellValue();
					String Specialtyhtml = OrContact.getRow(85).getCell(3).getStringCellValue();
					String SpecialtyAddhtml = OrContact.getRow(86).getCell(3).getStringCellValue();
					String AddressTypehtml = OrContact.getRow(19).getCell(3).getStringCellValue();
					String Address1html = OrContact.getRow(20).getCell(3).getStringCellValue();
					String Address2html = OrContact.getRow(21).getCell(3).getStringCellValue();
					String Statehtml = OrContact.getRow(22).getCell(3).getStringCellValue();
					String Cityhtml = OrContact.getRow(23).getCell(3).getStringCellValue();
					String Ziphtml = OrContact.getRow(24).getCell(3).getStringCellValue();
					String PreferredAddresshtml = OrContact.getRow(25).getCell(3).getStringCellValue();
					String AddPhonehtml = OrContact.getRow(31).getCell(3).getStringCellValue();
					String Phonetypehtml = OrContact.getRow(32).getCell(3).getStringCellValue();
					String Phonenumberhtml = OrContact.getRow(33).getCell(3).getStringCellValue();
					String Preferredphonehtml = OrContact.getRow(34).getCell(3).getStringCellValue();
					String Addfaxhtml = OrContact.getRow(36).getCell(3).getStringCellValue();
					String Faxnohtml = OrContact.getRow(38).getCell(3).getStringCellValue();
					String Preferredfaxhtml = OrContact.getRow(39).getCell(3).getStringCellValue();
					String Licensetypehtml = OrContact.getRow(50).getCell(3).getStringCellValue();
					String Licensenohtml = OrContact.getRow(51).getCell(3).getStringCellValue();
					String Savehtml = OrContact.getRow(55).getCell(3).getStringCellValue();
					String Cancelhtml = OrContact.getRow(57).getCell(3).getStringCellValue();

					// Getting Data From Excel Sheet
					String KSClient = DpContact.getRow(29).getCell(3).getStringCellValue();
					String PrescriberOrgname = DpContact.getRow(30).getCell(3).getStringCellValue();
					String Firstname = DpContact.getRow(31).getCell(3).getStringCellValue();
					String Middlename = DpContact.getRow(32).getCell(3).getStringCellValue();
					String Lastname = DpContact.getRow(33).getCell(3).getStringCellValue();
					String Title = DpContact.getRow(34).getCell(3).getStringCellValue();
					String Status = DpContact.getRow(35).getCell(3).getStringCellValue();
					String Specialty = DpContact.getRow(36).getCell(3).getStringCellValue();
					String Addresstype = DpContact.getRow(37).getCell(3).getStringCellValue();
					String Address1 = DpContact.getRow(38).getCell(3).getStringCellValue();
					String Address2 = DpContact.getRow(39).getCell(3).getStringCellValue();
					String State = DpContact.getRow(40).getCell(3).getStringCellValue();
					String City = DpContact.getRow(41).getCell(3).getStringCellValue();
					int Zipno = (int) DpContact.getRow(42).getCell(3).getNumericCellValue();
					String Zip = String.valueOf(Zipno);
					String Phonetype = DpContact.getRow(43).getCell(3).getStringCellValue();
					double Phoneno = DpContact.getRow(44).getCell(3).getNumericCellValue();
					String Phonenumber = String.valueOf(Phoneno);
					double Faxno = DpContact.getRow(46).getCell(3).getNumericCellValue();
					String Faxnumber = String.valueOf(Faxno);
					String Licensetype = DpContact.getRow(47).getCell(3).getStringCellValue();
					long Licenseno = (long) DpContact.getRow(48).getCell(3).getNumericCellValue();
					String Licensenumber = String.valueOf(Licenseno);

					Thread.sleep(3000);
					String AddPrescriberMainpracticepermission = DpContact.getRow(5).getCell(1).getStringCellValue();

					// Add Prescriber Main Practice
					if (AddPrescriberMainpracticepermission.equals("YES")) { // Check the Add Prescriber Main practice
																				// Permission

						String AddContactfromContactManagementhtml = OrContact.getRow(84).getCell(6)
								.getStringCellValue();
						WebElement AddContactfromsearch = driver
								.findElement(By.className(AddContactfromContactManagementhtml));
						wait.until(ExpectedConditions
								.visibilityOfElementLocated(By.className(AddContactfromContactManagementhtml)));
						AddContactfromsearch.click();
						Thread.sleep(3000);

						// Select type of organization
						wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(Orgtypehtml)));
						Select TypeofOrgelemenet = new Select(driver.findElement(By.xpath(Orgtypehtml)));
						TypeofOrgelemenet.selectByValue("PRESCRIBER");

						if (CTUser == false) {

							wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(KSClienthtml)));
							Select KSClientelemenet = new Select(driver.findElement(By.xpath(KSClienthtml)));
							Thread.sleep(2000);
							KSClientelemenet.selectByValue(KSClient);
						} else {

							Thread.sleep(4000);
							WebElement Organizationelement = driver.findElement(By.xpath(Organizationhtml)); // Click
																												// the
																												// Organization
																												// dropdown
							wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(Organizationhtml)));
							Organizationelement.click();
							Thread.sleep(2000);

							ArrayList<WebElement> options = (ArrayList<WebElement>) driver
									.findElements(By.tagName("a")); // Select dynamic value from Organization dropdown
							for (WebElement option : options) {

								if (option.getText().equalsIgnoreCase(PrescriberOrgname)) {
									option.click(); // click the desired option
									break;
								}
							}
						}
						wait.until(ExpectedConditions.visibilityOfElementLocated(By.id(Firstnamehtml)));
						WebElement Firstnameelement = driver.findElement(By.id(Firstnamehtml));
						Firstnameelement.clear();
						Firstnameelement.sendKeys(Firstname);

						wait.until(ExpectedConditions.visibilityOfElementLocated(By.id(Middlenamehtml)));
						WebElement Middlenameelement = driver.findElement(By.id(Middlenamehtml));
						Middlenameelement.clear();
						Middlenameelement.sendKeys(Middlename);

						wait.until(ExpectedConditions.visibilityOfElementLocated(By.id(Lastnamehtml)));
						WebElement Lastnameelement = driver.findElement(By.id(Lastnamehtml));
						Lastnameelement.clear();
						Lastnameelement.sendKeys(Lastname);

						wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(Titlehtml)));
						Select Titleelement = new Select(driver.findElement(By.xpath(Titlehtml)));
						Thread.sleep(2000);
						Titleelement.selectByVisibleText(Title);

						wait.until(ExpectedConditions.visibilityOfElementLocated(By.id(Statushtml)));
						Select Statuselement = new Select(driver.findElement(By.id(Statushtml)));
						Thread.sleep(2000);
						Statuselement.selectByVisibleText(Status);

						Thread.sleep(3000);
						WebElement Specialtyelement = driver.findElement(By.xpath(Specialtyhtml)); //// Click the
																									//// Specialty
																									//// dropdown
						wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(Specialtyhtml)));
						Specialtyelement.click();

						try {
							Thread.sleep(2000);

							ArrayList<WebElement> Spec = (ArrayList<WebElement>) driver.findElements(By.tagName("a")); // Select
																														// dynamic
																														// value
																														// from
																														// Specialty
																														// dropdown
							for (WebElement SubSpec : Spec) {

								if (SubSpec.getText().equalsIgnoreCase(Specialty)) {
									Thread.sleep(2000);
									SubSpec.click(); // click the desired option
									break;
								}
							}
						} catch (InterruptedException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}

						Thread.sleep(3000);
						WebElement SpecialtyAddelement = driver.findElement(By.xpath(SpecialtyAddhtml)); //// Click the
																											//// Specialty
																											//// Add
																											//// button
						SpecialtyAddelement.click();

						// Select Address Type
						wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(AddressTypehtml)));
						Select Addresstypeelement = new Select(driver.findElement(By.xpath(AddressTypehtml)));
						Thread.sleep(2000);
						Addresstypeelement.selectByVisibleText(Addresstype);

						// Add Address 1
						Thread.sleep(3000);
						wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(Address1html)));
						WebElement Address1element = driver.findElement(By.xpath(Address1html));
						((JavascriptExecutor) driver)
								.executeScript("window.scrollTo(0," + Address1element.getLocation().y + ")");
						Address1element.clear();
						Address1element.sendKeys(Address1);

						// Add Address 2
						Thread.sleep(3000);
						wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(Address2html)));
						WebElement Address2element = driver.findElement(By.xpath(Address2html));
						Address2element.clear();
						Address2element.sendKeys(Address2);

						// Select State
						wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(Statehtml)));
						Select Stateelement = new Select(driver.findElement(By.xpath(Statehtml)));
						Thread.sleep(3000);
						Stateelement.selectByVisibleText(State);

						// Select City
						wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(Cityhtml)));
						Select Cityelement = new Select(driver.findElement(By.xpath(Cityhtml)));
						Thread.sleep(3000);
						Cityelement.selectByVisibleText(City);

						// Select ZIP
						wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(Ziphtml)));
						Select Zipelement = new Select(driver.findElement(By.xpath(Ziphtml)));
						Thread.sleep(2000);
						Zipelement.selectByVisibleText(Zip);

						// Select Preferred Address checkbox
						WebElement PreferredAddresselement = driver.findElement(By.xpath(PreferredAddresshtml));
						wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(PreferredAddresshtml)));
						PreferredAddresselement.click();

						// Click on Add Phone Number link
						WebElement AddPhoneelement = driver.findElement(By.xpath(AddPhonehtml));
						wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(AddPhonehtml)));
						AddPhoneelement.click();

						// Select Phone Type
						wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(Phonetypehtml)));
						Select Phonetypeelement = new Select(driver.findElement(By.xpath(Phonetypehtml)));
						Thread.sleep(2000);
						Phonetypeelement.selectByVisibleText(Phonetype);

						// Add phone number
						wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(Phonenumberhtml)));
						WebElement Phonenoelement = driver.findElement(By.xpath(Phonenumberhtml));
						Phonenoelement.clear();
						Phonenoelement.sendKeys(Phonenumber);

						// Select Preferred Phone no,
						WebElement PreferredPhoneelement = driver.findElement(By.xpath(Preferredphonehtml));
						wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(Preferredphonehtml)));
						PreferredPhoneelement.click();

						// Click on Add Fax Number link
						WebElement Addfaxelement = driver.findElement(By.xpath(Addfaxhtml));
						wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(Addfaxhtml)));
						Addfaxelement.click();

						// Add Fax Number
						wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(Faxnohtml)));
						WebElement Faxnoelement = driver.findElement(By.xpath(Faxnohtml));
						Faxnoelement.clear();
						Faxnoelement.sendKeys(Faxnumber);

						// Preferred Fax checkbox
						WebElement Preferredfaxelement = driver.findElement(By.xpath(Preferredfaxhtml));
						wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(Preferredfaxhtml)));
						Thread.sleep(2000);
						Preferredfaxelement.click();

						// Select License type
						wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(Licensetypehtml)));
						Select Licensetypeelement = new Select(driver.findElement(By.xpath(Licensetypehtml)));
						Thread.sleep(2000);
						Licensetypeelement.selectByVisibleText(Licensetype);

						// Select License number
						wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(Licensenohtml)));
						WebElement Licensenoelement = driver.findElement(By.xpath(Licensenohtml));
						((JavascriptExecutor) driver)
								.executeScript("window.scrollTo(0," + Licensenoelement.getLocation().y + ")");
						Licensenoelement.clear();
						Licensenoelement.sendKeys(Licensenumber);

						// click on Save Button
						wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(Savehtml)));
						WebElement Saveelement = driver.findElement(By.xpath(Savehtml));
						Saveelement.click();

						try {
							Thread.sleep(3000);
							if ((driver.getTitle()).equals("Add Contact")) {
								try {
									// Handle mandatory fields validation
									if (driver.findElement(By.xpath("/html/body/section/ul")).isDisplayed()) {
										System.out.println(
												driver.findElement(By.xpath("/html/body/section/ul")).getText());
										System.out.println("Prescriber Contact not Added");
										Thread.sleep(2000);
										WebElement Cancel = driver.findElement(By.xpath(Cancelhtml));
										((JavascriptExecutor) driver)
												.executeScript("window.scrollTo(0," + Cancel.getLocation().y + ")");
										Cancel.click();
									} else {

									}
								} catch (Exception e) {
									// Handle duplicate patient warning model
									wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(
											"//*[@id='duplicateContactWarningModal']/div/div/div[3]/button[1]")));
									driver.findElement(By
											.xpath("//*[@id='duplicateContactWarningModal']/div/div/div[3]/button[1]"))
											.click();
									Thread.sleep(2000);
									System.out.println("Prescriber contact "
											+ driver.findElement(By.xpath("/html/body/section/div[1]")).getText());
								}

							} else {

								System.out.println("Prescriber main practice contact added successfully");
								test.log(LogStatus.INFO, "Prescriber main practice contact added successfully");
							}

						} catch (Exception e) {
							wait.until(ExpectedConditions.visibilityOfElementLocated(
									By.xpath("//*[@id='duplicateContactWarningModal']/div/div/div[3]/button[1]")));
							driver.findElement(
									By.xpath("//*[@id='duplicateContactWarningModal']/div/div/div[3]/button[1]"))
									.click();
							Thread.sleep(2000);
							System.out.println("Prescriber contact "
									+ driver.findElement(By.xpath("/html/body/section/div[1]")).getText());
						}

						/*
						 * Thread.sleep(4000); String HomeHtml =
						 * OrContact.getRow(87).getCell(3).getStringCellValue(); WebElement Home =
						 * driver.findElement(By.xpath(HomeHtml)); Home.click();
						 */

					} else {
						System.out.println("Add Prescriber Main Practice permission is NO");
					}

					// Check Edit Prescriber contact Permission
					Thread.sleep(4000);
					String HomeHtml = OrOrganization.getRow(66).getCell(3).getStringCellValue();
					WebElement Home = driver.findElement(By.xpath(HomeHtml));
					((JavascriptExecutor) driver).executeScript("window.scrollTo(0," + Home.getLocation().y + ")");
					Home.click();

				} else {
					System.out.println("Contact Permission is NO");
					test.log(LogStatus.INFO, "Contact Permission is NO");

				}

			} else {
				System.out.println("Login is not done");
			}

		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Test(priority = 6)
	public void Patient() {

		test = report.startTest("Patient");
		try {
			Thread.sleep(4000);
			String HomePageTitle = driver.getTitle();
			// Thread.sleep(2000);
			if (HomePageTitle.equals("KloudScript")) { // Check the Page title if we are reach at home page or not.
				// System.out.println("Ctuser"+CTUser);

				int i = 0;
				while (i < 1) {
					Thread.sleep(2000);
					if (driver.findElement(By.xpath("//*[@id=\'notificationDialogCloseButton\']")).isDisplayed()) {
						driver.findElement(By.xpath("//*[@id=\'notificationDialogCloseButton\']")).click();
					} else {
						i = 1;
					}
				}
				String Patientpermission = DpModulePermission.getRow(5).getCell(1).getStringCellValue();
				if (Patientpermission.equals("YES")) {

					// Getting all HTML Element From Excel
					WebDriverWait wait = new WebDriverWait(driver, 15);
					String PatientAction = DpPatient.getRow(1).getCell(0).getStringCellValue();
					if (PatientAction.equals("ADD") || PatientAction.equals("BOTH")) {

						String AddPatientHomeHTML = OrPatient.getRow(1).getCell(3).getStringCellValue();
						String PatientfirstnameHTML = OrPatient.getRow(2).getCell(3).getStringCellValue();
						String PatientLastnameHTML = OrPatient.getRow(4).getCell(3).getStringCellValue();
						String PatientDOBHTML = OrPatient.getRow(6).getCell(3).getStringCellValue();
						String PatientGenderHTML = OrPatient.getRow(7).getCell(3).getStringCellValue();
						String PatientKsClientHTML = OrPatient.getRow(8).getCell(3).getStringCellValue();
						String PatientStoreHTML = OrPatient.getRow(9).getCell(3).getStringCellValue();
						String PatientAddressTabHTML = OrPatient.getRow(11).getCell(3).getStringCellValue();
						// String PatientAddaddressLinkHTML =
						// OrPatient.getRow(12).getCell(3).getStringCellValue();
						// String PatientfirstAddressTypeHTML =
						// OrPatient.getRow(13).getCell(3).getStringCellValue();
						String PatientfirstAddress1HTML = OrPatient.getRow(14).getCell(3).getStringCellValue();
						String PatientfirstStateHTML = OrPatient.getRow(16).getCell(3).getStringCellValue();
						String PatientfirstCityHTML = OrPatient.getRow(17).getCell(3).getStringCellValue();
						String PatientfirstZipHTML = OrPatient.getRow(18).getCell(3).getStringCellValue();
						String PatientSaveHTML = OrPatient.getRow(82).getCell(3).getStringCellValue();
						String PatientDuplicationPopupsaveHTML = OrPatient.getRow(122).getCell(3).getStringCellValue();
						String StoreSearchHTML = OrPatient.getRow(123).getCell(6).getStringCellValue();

						/*
						 * System.out.println("addPatientHome"+":"+AddPatientHomeHTML);
						 * System.out.println("firsname"+":"+PatientfirstnameHTML);
						 * System.out.println("lastname"+":"+PatientLastnameHTML);
						 * System.out.println("DOB"+":"+PatientDOBHTML);
						 * System.out.println("gender"+":"+PatientGenderHTML);
						 * System.out.println("KsClient"+":"+PatientKsClientHTML);
						 * System.out.println("Store"+":"+PatientStoreHTML);
						 * System.out.println("addressTAB"+":"+PatientAddressTabHTML);
						 * //System.out.println("Addaddresslink"+":"+PatientAddaddressLinkHTML);
						 * //System.out.println("firstaddresstype"+":"+PatientfirstAddressTypeHTML);
						 * System.out.println("firstaddress1"+":"+PatientfirstAddress1HTML);
						 * System.out.println("State"+":"+PatientfirstStateHTML);
						 * System.out.println("City"+":"+PatientfirstCityHTML);
						 * System.out.println("Zip"+":"+PatientfirstZipHTML);
						 * System.out.println("Save"+":"+PatientSaveHTML);
						 * System.out.println("duplicaSave"+" : "+PatientDuplicationPopupsaveHTML);
						 * System.out.println("StoreSearch"+" : "+StoreSearchHTML);
						 */

						try {

							// Getting Data From Excel Sheet
							String PatientFirstName = DpPatient.getRow(1).getCell(1).getStringCellValue();
							String PatientLastName = DpPatient.getRow(1).getCell(2).getStringCellValue();
							String PatientDOB = DpPatient.getRow(1).getCell(3).getStringCellValue();
							String PatientGender = DpPatient.getRow(1).getCell(4).getStringCellValue();
							String PatientKsClientID = DpPatient.getRow(1).getCell(5).getStringCellValue();
							String PatientStoreID = DpPatient.getRow(1).getCell(6).getStringCellValue();
							String PatientAddress1 = DpPatient.getRow(1).getCell(7).getStringCellValue();
							String PatientState = DpPatient.getRow(1).getCell(9).getStringCellValue();
							String PatientCity = DpPatient.getRow(1).getCell(10).getStringCellValue();
							int PatientZipint = (int) DpPatient.getRow(1).getCell(11).getNumericCellValue();
							String PatientZip = Integer.toString(PatientZipint);

							/*
							 * System.out.println("FirstName"+" : "+PatientFirstName);
							 * System.out.println("LastName"+" : "+PatientLastName);
							 * System.out.println("DOB"+" : "+PatientDOB);
							 * System.out.println("Gender"+" : "+PatientGender);
							 * System.out.println("Ksclient"+" : "+PatientKsClientID);
							 * System.out.println("Store"+" : "+PatientStoreID);
							 * System.out.println("Address1"+" : "+PatientAddress1);
							 * System.out.println("State"+" : "+PatientState);
							 * System.out.println("City"+" : "+PatientCity);
							 * System.out.println("Zip"+" : "+PatientZip);
							 */

							wait.until(ExpectedConditions.elementToBeClickable(By.xpath(AddPatientHomeHTML)));
							WebElement AddPatientHomeElement = driver.findElement(By.xpath(AddPatientHomeHTML));
							AddPatientHomeElement.click();

							wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(PatientfirstnameHTML)));
							WebElement patientname = driver.findElement(By.xpath(PatientfirstnameHTML));
							patientname.clear();
							patientname.sendKeys(PatientFirstName);

							WebElement lastname = driver.findElement(By.xpath(PatientLastnameHTML));
							lastname.clear();
							lastname.sendKeys(PatientLastName);

							WebElement brdate = driver.findElement(By.xpath(PatientDOBHTML));
							brdate.clear();
							brdate.sendKeys(PatientDOB);

							Select Gender = new Select(driver.findElement(By.xpath(PatientGenderHTML)));
							Gender.selectByVisibleText(PatientGender);

							if (CTUser == false) {
								wait.until(ExpectedConditions.elementToBeClickable(By.xpath(PatientKsClientHTML)));
								Select tenetid = new Select(driver.findElement(By.xpath(PatientKsClientHTML)));
								tenetid.selectByValue(PatientKsClientID);

								Thread.sleep(2000);
								wait.until(ExpectedConditions.elementToBeClickable(By.xpath(PatientStoreHTML)));
								driver.findElement(By.xpath(PatientStoreHTML)).click();
								Thread.sleep(1000);

								Thread.sleep(2000);
								wait.until(ExpectedConditions.elementToBeClickable(By.className(StoreSearchHTML)));
								WebElement StoreSearchElement = driver.findElement(By.className(StoreSearchHTML));
								((JavascriptExecutor) driver)
										.executeScript("window.scrollTo(0," + StoreSearchElement.getLocation().y + ")");
								StoreSearchElement.clear();
								StoreSearchElement.sendKeys(PatientStoreID);

								Thread.sleep(2000);

								WebElement ele = Ketu.getExactListOfElements(driver,driver.findElement(By.xpath("//ul[@class='dropdown-menu noclose Add ']")),
										PatientStoreID);
						
								ele.click();

							}

							if (CTUser == true) {
							Thread.sleep(2000);
							wait.until(ExpectedConditions.elementToBeClickable(By.xpath(PatientStoreHTML)));
							driver.findElement(By.xpath(PatientStoreHTML)).click();
							Thread.sleep(1000);

							Thread.sleep(2000);
							wait.until(ExpectedConditions.elementToBeClickable(By.className(StoreSearchHTML)));
							WebElement StoreSearchElement = driver.findElement(By.className(StoreSearchHTML));
							((JavascriptExecutor) driver)
									.executeScript("window.scrollTo(0," + StoreSearchElement.getLocation().y + ")");
							StoreSearchElement.clear();
							StoreSearchElement.sendKeys(PatientStoreID);

							Thread.sleep(2000);
							WebElement ele = Ketu.getExactListOfElements(driver,driver.findElement(By.xpath("//ul[@class='dropdown-menu noclose add-patient-multiselect ']")),PatientStoreID);
					
							ele.click();


							Thread.sleep(4000);

							driver.findElement(By.xpath("//*[@id='patientForm']/section/div")).click();

							}
							wait.until(ExpectedConditions.elementToBeClickable(By.xpath(PatientAddressTabHTML)));
							WebElement AddressTabElement = driver.findElement(By.xpath(PatientAddressTabHTML));
							((JavascriptExecutor) driver)
									.executeScript("window.scrollTo(0," + AddressTabElement.getLocation().y + ")");
							AddressTabElement.click();

							try {
								Thread.sleep(1000);
							} catch (InterruptedException e1) {
								// TODO Auto-generated catch block
								e1.printStackTrace();
							}

							wait.until(
									ExpectedConditions.visibilityOfElementLocated(By.xpath(PatientfirstAddress1HTML)));
							WebElement PatientAddress1Element = driver.findElement(By.xpath(PatientfirstAddress1HTML));
							((JavascriptExecutor) driver)
									.executeScript("window.scrollTo(0," + PatientAddress1Element.getLocation().y + ")");
							PatientAddress1Element.sendKeys(PatientAddress1);

							try {
								Thread.sleep(1000);
							} catch (InterruptedException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}

							wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(PatientfirstStateHTML)));
							Select state = new Select(driver.findElement(By.xpath(PatientfirstStateHTML)));
							state.selectByValue(PatientState);
							try {
								Thread.sleep(2000);
							} catch (InterruptedException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}

							wait.until(ExpectedConditions.elementToBeClickable(By.xpath(PatientfirstCityHTML)));
							Select city = new Select(driver.findElement(By.xpath(PatientfirstCityHTML)));
							try {
								Thread.sleep(1000);
							} catch (InterruptedException e2) {
								// TODO Auto-generated catch block
								e2.printStackTrace();
							}
							city.selectByValue(PatientCity);

							wait.until(ExpectedConditions.elementToBeClickable(By.xpath(PatientfirstZipHTML)));
							Select zip = new Select(driver.findElement(By.xpath(PatientfirstZipHTML)));
							try {
								Thread.sleep(2000);
							} catch (InterruptedException e1) {
								// TODO Auto-generated catch block
								e1.printStackTrace();
							}
							zip.selectByValue(PatientZip);

							/*
							 * WebElement parentElement =
							 * driver.findElement(By.xpath("//*[@id=\'buttonGroup\']/div")); WebElement
							 * childElement = parentElement.findElement(By.xpath(PatientSaveHTML));
							 * childElement.submit();
							 */

							wait.until(ExpectedConditions
									.elementToBeClickable(driver.findElement(By.xpath(PatientSaveHTML))));
							WebElement SavePatientElement = driver.findElement(By.xpath(PatientSaveHTML));
							((JavascriptExecutor) driver)
									.executeScript("window.scrollTo(0," + SavePatientElement.getLocation().y + ")");
							SavePatientElement.click();

							try {
								Thread.sleep(2000);
							} catch (InterruptedException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}

							try {
								WebElement PatientDuplicatePopupElement = driver
										.findElement(By.xpath(PatientDuplicationPopupsaveHTML));
								((JavascriptExecutor) driver).executeScript(
										"window.scrollTo(0," + PatientDuplicatePopupElement.getLocation().y + ")");
								PatientDuplicatePopupElement.click();
								Thread.sleep(3000);
								System.out.println("Patient "
										+ driver.findElement(By.xpath("/html/body/section/div[1]")).getText());
								test.log(LogStatus.INFO, "Patient "
										+ driver.findElement(By.xpath("/html/body/section/div[1]")).getText());

							} catch (Exception e) {
								// TODO: handle exception
								System.out.println("Patient "
										+ driver.findElement(By.xpath("/html/body/section/div[1]")).getText());
								test.log(LogStatus.INFO, "Patient "
										+ driver.findElement(By.xpath("/html/body/section/div[1]")).getText());
							}

						} catch (Exception e) {
							// TODO: handle exception
							System.out.println(e.getMessage());
						}
					}
					if (PatientAction.equals("EDIT") || PatientAction.equals("BOTH")) {
						if (driver.getTitle().equals("KloudScript")) {
							String SearchPatientHomeHTML = OrPatient.getRow(86).getCell(3).getStringCellValue();

							WebElement SearchPatientHomeElement = driver.findElement(By.xpath(SearchPatientHomeHTML));
							SearchPatientHomeElement.click();

							Thread.sleep(2000);
						}

						String PatientSearchFirstnameHTML = OrPatient.getRow(88).getCell(3).getStringCellValue();
						String PatientSearchLastnameHTML = OrPatient.getRow(90).getCell(3).getStringCellValue();
						String PatientSearchDOBHTML = OrPatient.getRow(91).getCell(3).getStringCellValue();
						String PatientSearchHTML = OrPatient.getRow(96).getCell(3).getStringCellValue();
						String PatientfirstnameHTML = OrPatient.getRow(2).getCell(3).getStringCellValue();
						String PatientLastnameHTML = OrPatient.getRow(4).getCell(3).getStringCellValue();
						String PatientDOBHTML = OrPatient.getRow(6).getCell(3).getStringCellValue();
						String PatientGenderHTML = OrPatient.getRow(7).getCell(3).getStringCellValue();
						String PatientAddressTabHTML = OrPatient.getRow(11).getCell(3).getStringCellValue();
						String PatientAddAddressHTML = OrPatient.getRow(12).getCell(3).getStringCellValue();
						String PatientSaveHTML = OrPatient.getRow(82).getCell(3).getStringCellValue();
						String PatientDuplicationPopupsaveHTML = OrPatient.getRow(122).getCell(3).getStringCellValue();

						String PatientFirstName = DpPatient.getRow(1).getCell(1).getStringCellValue();
						String PatientLastName = DpPatient.getRow(1).getCell(2).getStringCellValue();
						String PatientDOB = DpPatient.getRow(1).getCell(3).getStringCellValue();
						String PatientGender = DpPatient.getRow(1).getCell(4).getStringCellValue();
						String PatientAddress1 = DpPatient.getRow(1).getCell(7).getStringCellValue();
						String PatientState = DpPatient.getRow(1).getCell(9).getStringCellValue();
						String PatientCity = DpPatient.getRow(1).getCell(10).getStringCellValue();
						int PatientZipint = (int) DpPatient.getRow(1).getCell(11).getNumericCellValue();
						String PatientZip = Integer.toString(PatientZipint);

						wait.until(ExpectedConditions
								.elementToBeClickable(driver.findElement(By.xpath(PatientSearchFirstnameHTML))));
						WebElement PatientSearchFirstnameElement = driver
								.findElement(By.xpath(PatientSearchFirstnameHTML));
						PatientSearchFirstnameElement.clear();
						PatientSearchFirstnameElement.sendKeys(PatientFirstName);

						wait.until(ExpectedConditions
								.elementToBeClickable(driver.findElement(By.xpath(PatientSearchLastnameHTML))));
						WebElement PatientSearchLastnameElement = driver
								.findElement(By.xpath(PatientSearchLastnameHTML));
						PatientSearchLastnameElement.clear();
						PatientSearchLastnameElement.sendKeys(PatientLastName);

						wait.until(ExpectedConditions
								.elementToBeClickable(driver.findElement(By.xpath(PatientSearchDOBHTML))));
						WebElement PatientSearchDOBElement = driver.findElement(By.xpath(PatientSearchDOBHTML));
						PatientSearchDOBElement.clear();
						PatientSearchDOBElement.sendKeys(PatientDOB);

						wait.until(ExpectedConditions
								.elementToBeClickable(driver.findElement(By.xpath(PatientSearchHTML))));
						WebElement PatientSearchElement = driver.findElement(By.xpath(PatientSearchHTML));
						PatientSearchElement.click();

						try {
							wait.until(ExpectedConditions.elementToBeClickable(driver.findElement(
									By.xpath("//*[@id=\'listGridDiv\']/div[1]/table/tbody/tr[1]/td[2]/a"))));
							WebElement firstpatientrecord = driver
									.findElement(By.xpath("//*[@id=\'listGridDiv\']/div[1]/table/tbody/tr[1]/td[2]/a"));
							Thread.sleep(2000);
							((JavascriptExecutor) driver)
							.executeScript("window.scrollTo(0," + firstpatientrecord.getLocation().y + ")");
							firstpatientrecord.click();
						} catch (Exception e) {
							// TODO: handle exception
							System.out.println("Patient Not Found");
						}

						wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(PatientfirstnameHTML)));
						WebElement patientname = driver.findElement(By.xpath(PatientfirstnameHTML));
						patientname.clear();
						patientname.sendKeys(PatientFirstName);

						WebElement lastname = driver.findElement(By.xpath(PatientLastnameHTML));
						lastname.clear();
						lastname.sendKeys(PatientLastName);

						WebElement brdate = driver.findElement(By.xpath(PatientDOBHTML));
						brdate.clear();
						brdate.sendKeys(PatientDOB);

						Select Gender = new Select(driver.findElement(By.xpath(PatientGenderHTML)));
						Gender.selectByVisibleText(PatientGender);

						Thread.sleep(2000);

						System.out.println("Edit pharmacy");
						wait.until(ExpectedConditions.elementToBeClickable(By.xpath(PatientAddressTabHTML)));
						WebElement AddressTabElement = driver.findElement(By.xpath(PatientAddressTabHTML));
						((JavascriptExecutor) driver)
								.executeScript("window.scrollTo(0," + AddressTabElement.getLocation().y + ")");
						AddressTabElement.click();

						try {
							Thread.sleep(1000);
						} catch (InterruptedException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}

						wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(PatientAddAddressHTML)));
						WebElement PatientAddAddressElement = driver.findElement(By.xpath(PatientAddAddressHTML));
						((JavascriptExecutor) driver)
								.executeScript("window.scrollTo(0," + PatientAddAddressElement.getLocation().y + ")");
						PatientAddAddressElement.click();

						try {
							Thread.sleep(1000);
						} catch (InterruptedException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}

						List<WebElement> addressrow = driver.findElements(By.linkText("Edit"));

						Thread.sleep(2000);
						int row = addressrow.size();
						// System.out.println(row);

						wait.until(ExpectedConditions
								.visibilityOfElementLocated(By.xpath("//*[@id=\"addressList" + row + "_address1\"]")));
						WebElement PatientAddress1Element = driver
								.findElement(By.xpath("//*[@id=\"addressList" + row + "_address1\"]"));
						((JavascriptExecutor) driver)
								.executeScript("window.scrollTo(0," + PatientAddress1Element.getLocation().y + ")");
						PatientAddress1Element.sendKeys(PatientAddress1);

						try {
							Thread.sleep(1000);
						} catch (InterruptedException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}

						wait.until(ExpectedConditions
								.visibilityOfElementLocated(By.xpath("//*[@id=\"addressList" + row + "_state\"]")));
						Select state = new Select(
								driver.findElement(By.xpath("//*[@id=\"addressList" + row + "_state\"]")));
						state.selectByValue(PatientState);
						try {
							Thread.sleep(2000);
						} catch (InterruptedException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}

						wait.until(ExpectedConditions
								.elementToBeClickable(By.xpath("//*[@id=\"addressList" + row + "_city\"]")));
						Select city = new Select(
								driver.findElement(By.xpath("//*[@id=\"addressList" + row + "_city\"]")));
						try {
							Thread.sleep(1000);
						} catch (InterruptedException e2) {
							// TODO Auto-generated catch block
							e2.printStackTrace();
						}
						city.selectByValue(PatientCity);

						wait.until(ExpectedConditions
								.elementToBeClickable(By.xpath("//*[@id=\"addressList" + row + "_zip\"]")));
						Select zip = new Select(
								driver.findElement(By.xpath("//*[@id=\"addressList" + row + "_zip\"]")));
						try {
							Thread.sleep(2000);
						} catch (InterruptedException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
						zip.selectByValue(PatientZip);

						/*
						 * WebElement parentElement =
						 * driver.findElement(By.xpath("//*[@id=\'buttonGroup\']/div")); WebElement
						 * childElement = parentElement.findElement(By.xpath(PatientSaveHTML));
						 * childElement.submit();
						 */

						wait.until(
								ExpectedConditions.elementToBeClickable(driver.findElement(By.xpath(PatientSaveHTML))));
						WebElement SavePatientElement = driver.findElement(By.xpath(PatientSaveHTML));
						((JavascriptExecutor) driver)
								.executeScript("window.scrollTo(0," + SavePatientElement.getLocation().y + ")");
						SavePatientElement.click();

						try {
							Thread.sleep(2000);
						} catch (InterruptedException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}

						try {
							WebElement PatientDuplicatePopupElement = driver
									.findElement(By.xpath(PatientDuplicationPopupsaveHTML));
							((JavascriptExecutor) driver).executeScript(
									"window.scrollTo(0," + PatientDuplicatePopupElement.getLocation().y + ")");
							PatientDuplicatePopupElement.click();
							Thread.sleep(3000);
							System.out.println(
									"Patient " + driver.findElement(By.xpath("/html/body/section/div[1]")).getText());
							test.log(LogStatus.INFO,
									"Patient" + driver.findElement(By.xpath("/html/body/section/div[1]")).getText());

						} catch (Exception e) {
							// TODO: handle exception
							System.out.println(
									"Patient " + driver.findElement(By.xpath("/html/body/section/div[1]")).getText());
							test.log(LogStatus.INFO,
									"Patient " + driver.findElement(By.xpath("/html/body/section/div[1]")).getText());
						}

					} else {
						System.out.println("Not get Edit Action for Patient");
					}
					Thread.sleep(4000);
					String HomeHtml = OrOrganization.getRow(66).getCell(3).getStringCellValue();
					WebElement Home = driver.findElement(By.xpath(HomeHtml));
					((JavascriptExecutor) driver).executeScript("window.scrollTo(0," + Home.getLocation().y + ")");
					Home.click();

				} else {
					// Patient Permission is no than come here
					System.out.println("Patient Permission is NO");

					test.log(LogStatus.INFO, "Patient Permission is NO");
				}

			}
		} catch (Exception e) {
			// TODO: handle exception
			e.getMessage();

		}
	}

	@Test(priority = 7)
	public void ServicePreferencesTab() {

		test = report.startTest("Service Preference");
		try {
			Thread.sleep(4000);

			String HomePageTitle = driver.getTitle();
			// Thread.sleep(2000);
			if (!HomePageTitle.equals("Login")) { // Check the Page title if we are reach at home page or not.
				WebDriverWait wait = new WebDriverWait(driver, 15);
				int ii = 0;
				while (ii < 1) {
					Thread.sleep(2000);
					if (driver.findElement(By.xpath("//*[@id=\'notificationDialogCloseButton\']")).isDisplayed()) {
						driver.findElement(By.xpath("//*[@id=\'notificationDialogCloseButton\']")).click();
					} else {
						ii = 1;
					}
				}
				String ServicePreferencesTabpermission = DpModulePermission.getRow(7).getCell(1).getStringCellValue();
				if (ServicePreferencesTabpermission.equals("YES")) {
					// System.out.println("Serice Preferecnces Tab is Yes ");

					String ServicePreferencesTabHTML = OrServicePreferences_tab.getRow(1).getCell(3)
							.getStringCellValue();

					try {
						if (driver.findElement(By.xpath(ServicePreferencesTabHTML)).isDisplayed()) {
							// System.out.println("Service Preferences tab is visible");

						}
					} catch (Exception e) {
						// TODO: handle exception
						System.out.println("Service Preferences tab is Not visible");
						String PatientSearchFirstnameHTML = OrPatient.getRow(88).getCell(3).getStringCellValue();
						String PatientSearchLastnameHTML = OrPatient.getRow(90).getCell(3).getStringCellValue();
						String PatientSearchDOBHTML = OrPatient.getRow(91).getCell(3).getStringCellValue();
						String PatientSearchHTML = OrPatient.getRow(96).getCell(3).getStringCellValue();

						String PatientFirstName = DpPatient.getRow(1).getCell(1).getStringCellValue();
						String PatientLastName = DpPatient.getRow(1).getCell(2).getStringCellValue();
						String PatientDOB = DpPatient.getRow(1).getCell(3).getStringCellValue();

						Thread.sleep(2000);

						String SearchPatientHomeHTML = OrPatient.getRow(86).getCell(3).getStringCellValue();

						WebElement SearchPatientHomeElement = driver.findElement(By.xpath(SearchPatientHomeHTML));
						SearchPatientHomeElement.click();

						Thread.sleep(2000);
						
						wait.until(ExpectedConditions
								.elementToBeClickable(driver.findElement(By.xpath(PatientSearchFirstnameHTML))));
						WebElement PatientSearchFirstnameElement = driver
								.findElement(By.xpath(PatientSearchFirstnameHTML));
						PatientSearchFirstnameElement.clear();
						PatientSearchFirstnameElement.sendKeys(PatientFirstName);

						wait.until(ExpectedConditions
								.elementToBeClickable(driver.findElement(By.xpath(PatientSearchLastnameHTML))));
						WebElement PatientSearchLastnameElement = driver
								.findElement(By.xpath(PatientSearchLastnameHTML));
						PatientSearchLastnameElement.clear();
						PatientSearchLastnameElement.sendKeys(PatientLastName);

						wait.until(ExpectedConditions
								.elementToBeClickable(driver.findElement(By.xpath(PatientSearchDOBHTML))));
						WebElement PatientSearchDOBElement = driver.findElement(By.xpath(PatientSearchDOBHTML));
						PatientSearchDOBElement.clear();
						PatientSearchDOBElement.sendKeys(PatientDOB);

						wait.until(ExpectedConditions
								.elementToBeClickable(driver.findElement(By.xpath(PatientSearchHTML))));
						WebElement PatientSearchElement = driver.findElement(By.xpath(PatientSearchHTML));
						PatientSearchElement.click();

						try {
							Thread.sleep(3000);
							wait.until(ExpectedConditions.elementToBeClickable(driver.findElement(
									By.xpath("//*[@id=\'listGridDiv\']/div[1]/table/tbody/tr[1]/td[2]/a"))));
							
							WebElement firstpatientrecord = driver
									.findElement(By.xpath("//*[@id=\'listGridDiv\']/div[1]/table/tbody/tr[1]/td[2]/a"));
							Thread.sleep(2000);
							((JavascriptExecutor) driver).executeScript("window.scrollTo(0," + firstpatientrecord.getLocation().y +")");
							firstpatientrecord.click();
						} catch (Exception ee) {
							// TODO: handle exception
							System.out.println("Patient Not Found for Service Preferences Tab");
						}
					}

					Thread.sleep(2000);

					WebElement ServicePreferencesTabElement = driver.findElement(By.xpath(ServicePreferencesTabHTML));
					wait.until(ExpectedConditions
							.elementToBeClickable(driver.findElement(By.xpath(ServicePreferencesTabHTML))));
					ServicePreferencesTabElement.click();

					String TherapaticProgram = DpServicePreferences_tab.getRow(1).getCell(0).getStringCellValue();
					// String TherapaticeProgram = "Crohn's Disease";

					String EnrollHTML = OrServicePreferences_tab.getRow(2).getCell(3).getStringCellValue();
					String TherapaticProgramHTML = OrServicePreferences_tab.getRow(3).getCell(3).getStringCellValue();
					String StatusHTML = OrServicePreferences_tab.getRow(4).getCell(3).getStringCellValue();
					String ReasonHTML = OrServicePreferences_tab.getRow(5).getCell(3).getStringCellValue();
					String PatientNewToPharmacyYesHTML = OrServicePreferences_tab.getRow(6).getCell(3)
							.getStringCellValue();
					String PatientNewToPharmacyNoHTML = OrServicePreferences_tab.getRow(7).getCell(3)
							.getStringCellValue();
					String PatientNewToSepcialityYesHTML = OrServicePreferences_tab.getRow(8).getCell(3)
							.getStringCellValue();
					String PatientNewToSepcialityNoHTML = OrServicePreferences_tab.getRow(9).getCell(3)
							.getStringCellValue();
					String SaveTherapaticeHTML = OrServicePreferences_tab.getRow(10).getCell(3).getStringCellValue();
					String CloseTherapaticHTML = OrServicePreferences_tab.getRow(11).getCell(3).getStringCellValue();

					String Status = DpServicePreferences_tab.getRow(1).getCell(1).getStringCellValue();
					String Reason = DpServicePreferences_tab.getRow(1).getCell(2).getStringCellValue();
					String PatientNewToPharmacy = DpServicePreferences_tab.getRow(1).getCell(3).getStringCellValue();
					String PatientNewToSpeciality = DpServicePreferences_tab.getRow(1).getCell(4).getStringCellValue();

					// System.out.println(TherapaticProgram+" "+Status+" "+Reason+"
					// "+PatientNewToPharmacy+" "+PatientNewToSpeciality);
					Thread.sleep(2000);

					driver.findElement(By.xpath(EnrollHTML)).click();

					Thread.sleep(2000);

					// Get Parent window handle
					String winHandleBefore = driver.getWindowHandle();
					for (String winHandle : driver.getWindowHandles()) {
						// Switch to child window
						driver.switchTo().window(winHandle);
					}
					wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(TherapaticProgramHTML)));
					boolean therapaticexist = false;
					try {
						Select therapeuticProgram = new Select(driver.findElement(By.xpath(TherapaticProgramHTML)));
						therapeuticProgram.selectByVisibleText(TherapaticProgram);
						therapaticexist = false;

					} catch (Exception e) {
						// TODO: handle exception
						System.out.println(TherapaticProgram + " is already exist or not available");
						therapaticexist = true;
						driver.findElement(By.xpath(CloseTherapaticHTML)).click();
					}

					Thread.sleep(2000);

					try {

						if (therapaticexist == false) {

							wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(StatusHTML)));
							Select statusCode = new Select(driver.findElement(By.xpath(StatusHTML)));
							statusCode.selectByValue(Status);

							Thread.sleep(2000);

							wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(ReasonHTML)));
							Select subStatusCode = new Select(driver.findElement(By.xpath(ReasonHTML)));
							subStatusCode.selectByValue(Reason);

							Thread.sleep(2000);
							try {
								if (PatientNewToPharmacy.equalsIgnoreCase("YES")) {
									driver.findElement(By.xpath(PatientNewToPharmacyYesHTML)).click();
								}
							} catch (Exception e) {
								// TODO: handle exception
								driver.findElement(By.xpath(PatientNewToPharmacyNoHTML)).click();
							}
							Thread.sleep(1000);
							try {
								if (PatientNewToSpeciality.equalsIgnoreCase("YES")) {
									driver.findElement(By.xpath(PatientNewToSepcialityYesHTML)).click();
								}
							} catch (Exception e) {
								// TODO: handle exception
								driver.findElement(By.xpath(PatientNewToSepcialityNoHTML)).click();
							}

							WebElement SaveServicePreference = driver.findElement(By.xpath(SaveTherapaticeHTML));
							SaveServicePreference.click();
							// to close the child window.
							// driver.close();

							Thread.sleep(2000);

							// to switch to parent window.
							// driver.switchto.window(winHandleBefore);
							driver.switchTo().window(winHandleBefore);

							Thread.sleep(2000);
							System.out.println(TherapaticProgram + " Service Preference Added Successfullly");
							test.log(LogStatus.INFO, "Service Preference Added Successfullly");
						}

					} catch (Exception e) {
						// TODO: handle exception
						System.out.println("Service Preference Not Added Successfully");
						test.log(LogStatus.INFO, "Service Preference Not Added Successfully");
						e.getMessage();
					}
				} else {
					System.out.println("Service Preferences Tab permission is NO");
					test.log(LogStatus.INFO, "Service Preferences Tab permission is NO");
				}

			} else {

				System.out.println("Login is not done");
			}

		} catch (Exception e) {
			// TODO: handle exception
			e.getMessage();
		}
	}

//
	// @Test(priority = 7)
	// public void PayorTab() {
	//
	// try {
	// Thread.sleep(4000);
	// String HomePageTitle = driver.getTitle();
	//
	// // Thread.sleep(2000);
	// if (!HomePageTitle.equals("Login")) { // Check the Page title if we are reach
	// at home page or not.
	//
	// System.out.println("Check");
	// int ii = 0;
	// while (ii < 1) {
	// Thread.sleep(2000);
	// if
	// (driver.findElement(By.xpath("//*[@id=\'notificationDialogCloseButton\']")).isDisplayed())
	// {
	// driver.findElement(By.xpath("//*[@id=\'notificationDialogCloseButton\']")).click();
	// } else {
	// ii = 1;
	// }
	// }
	// String PayorTabpermission =
	// DpModulePermission.getRow(6).getCell(1).getStringCellValue();
	// if (PayorTabpermission.equals("YES")) {
	//
	// System.out.println("Permiso yessssssss");
	//
	// String PatientSearchFirstnameHTML =
	// OrPatient.getRow(88).getCell(3).getStringCellValue();
	// String PatientSearchLastnameHTML =
	// OrPatient.getRow(90).getCell(3).getStringCellValue();
	// String PatientSearchDOBHTML =
	// OrPatient.getRow(91).getCell(3).getStringCellValue();
	// String PatientSearchHTML =
	// OrPatient.getRow(96).getCell(3).getStringCellValue();
	//
	// String PatientFirstName =
	// DpPatient.getRow(1).getCell(1).getStringCellValue();
	// String PatientLastName = DpPatient.getRow(1).getCell(2).getStringCellValue();
	// String PatientDOB = DpPatient.getRow(1).getCell(3).getStringCellValue();
	//
	// WebDriverWait wait = new WebDriverWait(driver, 15);
	// try {
	// Thread.sleep(2000);
	// } catch (InterruptedException e) {
	// // TODO Auto-generated catch block
	// e.printStackTrace();
	// }
	// if (driver.getTitle().equals("KloudScript")) {
	// String SearchPatientHomeHTML =
	// OrPatient.getRow(86).getCell(3).getStringCellValue();
	//
	// WebElement SearchPatientHomeElement =
	// driver.findElement(By.xpath(SearchPatientHomeHTML));
	// SearchPatientHomeElement.click();
	// try {
	// Thread.sleep(2000);
	// } catch (InterruptedException e2) {
	// // TODO Auto-generated catch block
	// e2.printStackTrace();
	// }
	// wait.until(ExpectedConditions
	// .elementToBeClickable(driver.findElement(By.xpath(PatientSearchFirstnameHTML))));
	// WebElement PatientSearchFirstnameElement = driver
	// .findElement(By.xpath(PatientSearchFirstnameHTML));
	// PatientSearchFirstnameElement.clear();
	// PatientSearchFirstnameElement.sendKeys(PatientFirstName);
	//
	// wait.until(ExpectedConditions
	// .elementToBeClickable(driver.findElement(By.xpath(PatientSearchLastnameHTML))));
	// WebElement PatientSearchLastnameElement = driver
	// .findElement(By.xpath(PatientSearchLastnameHTML));
	// PatientSearchLastnameElement.clear();
	// PatientSearchLastnameElement.sendKeys(PatientLastName);
	//
	// wait.until(ExpectedConditions
	// .elementToBeClickable(driver.findElement(By.xpath(PatientSearchDOBHTML))));
	// WebElement PatientSearchDOBElement =
	// driver.findElement(By.xpath(PatientSearchDOBHTML));
	// PatientSearchDOBElement.clear();
	// PatientSearchDOBElement.sendKeys(PatientDOB);
	//
	// wait.until(ExpectedConditions
	// .elementToBeClickable(driver.findElement(By.xpath(PatientSearchHTML))));
	// WebElement PatientSearchElement =
	// driver.findElement(By.xpath(PatientSearchHTML));
	// PatientSearchElement.click();
	//
	// try {
	// Thread.sleep(3000);
	// wait.until(ExpectedConditions.elementToBeClickable(driver.findElement(
	// By.xpath("//*[@id=\'listGridDiv\']/div[1]/table/tbody/tr[1]/td[2]/a"))));
	// WebElement firstpatientrecord = driver
	// .findElement(By.xpath("//*[@id=\'listGridDiv\']/div[1]/table/tbody/tr[1]/td[2]/a"));
	// ((JavascriptExecutor) driver)
	// .executeScript("window.scrollTo(0," + firstpatientrecord.getLocation().y +
	// ")");
	// Thread.sleep(2000);
	// firstpatientrecord.click();
	// } catch (Exception e) {
	// // TODO: handle exception
	// System.out.println("Patient Not Found for Payor Tab");
	// }
	// }
	// Thread.sleep(2000);
	// String Payor_tabHTML = OrPayor_tab.getRow(1).getCell(3).getStringCellValue();
	// WebElement PayorTab = driver.findElement(By.xpath(Payor_tabHTML));
	// ((JavascriptExecutor) driver).executeScript("window.scrollTo(0," +
	// PayorTab.getLocation().y + ")");
	// wait.until(ExpectedConditions.elementToBeClickable(By.xpath(Payor_tabHTML)));
	// PayorTab.click();
	//
	// // Add Foundational Co-Pay Support
	// try {
	// Thread.sleep(1000);
	// } catch (InterruptedException e2) {
	// // TODO Auto-generated catch block
	// e2.printStackTrace();
	// }
	//
	// int row = DpPayor_tab.getLastRowNum();
	// for (int i = 1; i <= row; i++) {
	//
	// String PayorInsuranceTypePermission =
	// DpPayor_tab.getRow(i).getCell(1).getStringCellValue();
	// if (PayorInsuranceTypePermission.equals("ADD")) {
	// String AddInsuranceLinkHTML =
	// OrPayor_tab.getRow(2).getCell(3).getStringCellValue();
	// driver.findElement(By.xpath(AddInsuranceLinkHTML)).click();
	//
	// try {
	// Thread.sleep(2000);
	// } catch (InterruptedException e) {
	// // TODO Auto-generated catch block
	// e.printStackTrace();
	// }
	//
	// // Store the current window handle
	// // String winHandleBefore = driver.getWindowHandle();
	//
	// // Perform the click operation that opens new window
	//
	// // Switch to new window opened
	// /*
	// * for(String winHandle : driver.getWindowHandles()){
	// * driver.switchTo().window(winHandle);
	// *
	// * }
	// */
	//
	// // Get Parent window handle
	// String winHandleBefore = driver.getWindowHandle();
	// for (String winHandle : driver.getWindowHandles()) {
	// // Switch to child window
	// driver.switchTo().window(winHandle);
	// }
	//
	// /*
	// * // Do some operation on child window and get child window handle. String
	// * winHandleAfter = driver.getWindowHandle();
	// *
	// * //switch to child window of 1st child window. for(String winChildHandle :
	// * driver.getWindowHandles()) { // Switch to child window of the 1st child
	// * window. if(!winChildHandle.equals(winHandleBefore) &&
	// * !winChildHandle.equals(winHandleAfter)) {
	// * driver.switchTo().window(winChildHandle); } }
	// */
	//
	// // Do some operation on child window of 1st child window.
	// // to close the child window of 1st child window.
	// // driver.close();
	// try {
	//
	// Thread.sleep(2000);
	// String InsurancetypeHTML =
	// OrPayor_tab.getRow(3).getCell(3).getStringCellValue();
	// String Insurancetype = DpPayor_tab.getRow(i).getCell(0).getStringCellValue();
	// wait.until(ExpectedConditions
	// .visibilityOfAllElementsLocatedBy(By.xpath(InsurancetypeHTML)));
	// Select instypeelement = new
	// Select(driver.findElement(By.xpath(InsurancetypeHTML)));
	// Thread.sleep(1000);
	// instypeelement.selectByVisibleText(Insurancetype);
	//
	// String PlannameHTML = OrPayor_tab.getRow(4).getCell(3).getStringCellValue();
	// String Planname = DpPayor_tab.getRow(i).getCell(3).getStringCellValue();
	// wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath(PlannameHTML)));
	// WebElement plannameelement = driver.findElement(By.xpath(PlannameHTML));
	// plannameelement.clear();
	// plannameelement.sendKeys(Planname);
	//
	// String PhonnumberHTML =
	// OrPayor_tab.getRow(5).getCell(3).getStringCellValue();
	// int Phonnumberint = (int)
	// DpPayor_tab.getRow(i).getCell(4).getNumericCellValue();
	// String Phonenumber = String.valueOf(Phonnumberint);
	// wait.until(
	// ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath(PhonnumberHTML)));
	// WebElement phnoelement = driver.findElement(By.xpath(PhonnumberHTML));
	// phnoelement.clear();
	// phnoelement.sendKeys(Phonenumber);
	//
	// String CoveragetypeHTML =
	// OrPayor_tab.getRow(6).getCell(3).getStringCellValue();
	// String Coveragetype = DpPayor_tab.getRow(i).getCell(5).getStringCellValue();
	// wait.until(ExpectedConditions
	// .visibilityOfAllElementsLocatedBy(By.xpath(CoveragetypeHTML)));
	// Select coverageTypeelement = new
	// Select(driver.findElement(By.xpath(CoveragetypeHTML)));
	// coverageTypeelement.selectByVisibleText(Coveragetype);
	//
	// String PayorplanHTML = OrPayor_tab.getRow(7).getCell(3).getStringCellValue();
	// String Payorplan = DpPayor_tab.getRow(i).getCell(6).getStringCellValue();
	// wait.until(
	// ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath(PayorplanHTML)));
	// Select Payortypeelement = new
	// Select(driver.findElement(By.xpath(PayorplanHTML)));
	// Payortypeelement.selectByVisibleText(Payorplan);
	//
	// Thread.sleep(1000);
	// String BINHTML = OrPayor_tab.getRow(8).getCell(3).getStringCellValue();
	// int BINint = (int) DpPayor_tab.getRow(i).getCell(7).getNumericCellValue();
	// String BIN = String.valueOf(BINint);
	// wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath(BINHTML)));
	// WebElement patientInsuranceBINIDelement =
	// driver.findElement(By.xpath(BINHTML));
	// patientInsuranceBINIDelement.clear();
	// patientInsuranceBINIDelement.sendKeys(BIN);
	//
	// Thread.sleep(1000);
	// String InsuranceIdHTML =
	// OrPayor_tab.getRow(9).getCell(3).getStringCellValue();
	// int InsuranceIdint = (int)
	// DpPayor_tab.getRow(i).getCell(8).getNumericCellValue();
	// String InsuranceId = String.valueOf(InsuranceIdint);
	// wait.until(
	// ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath(InsuranceIdHTML)));
	// WebElement patientInsuranceIDelement =
	// driver.findElement(By.xpath(InsuranceIdHTML));
	// patientInsuranceIDelement.clear();
	// patientInsuranceIDelement.sendKeys(InsuranceId);
	//
	// Thread.sleep(1000);
	// String SavePayorHTML =
	// OrPayor_tab.getRow(10).getCell(3).getStringCellValue();
	// wait.until(
	// ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath(SavePayorHTML)));
	// WebElement SavePayorelement = driver.findElement(By.xpath(SavePayorHTML));
	// SavePayorelement.click();
	// Thread.sleep(1000);
	// System.out.println(
	// DpPayor_tab.getRow(i).getCell(0).getStringCellValue() + " Insurance is
	// added");
	// } catch (Exception e) {
	// // TODO: handle exception
	// System.out.println(e.getMessage());
	// }
	//
	// // to close the child window.
	// // driver.close();
	// try {
	// Thread.sleep(2000);
	// } catch (InterruptedException e1) {
	// // TODO Auto-generated catch block
	// e1.printStackTrace();
	// }
	//
	// // to switch to parent window.
	// // driver.switchto.window(winHandleBefore);
	// driver.switchTo().window(winHandleBefore);
	// try {
	// Thread.sleep(2000);
	// } catch (InterruptedException e) {
	// // TODO Auto-generated catch block
	// e.printStackTrace();
	// }
	// } else if (PayorInsuranceTypePermission.equals("NOTHING")) {
	//
	// System.out.println("Permission is NOTHING for "
	// + DpPayor_tab.getRow(i).getCell(0).getStringCellValue() + " Insurance");
	// } else {
	// System.out.println("Payor tab permission is wrong");
	// }
	//
	// }
	//
	// } else {
	// System.out.println("Payor tab Permission is NO");
	// }
	//
	// } else {
	// System.out.println("Login is not done");
	// }
	// } catch (Exception e) {
	// // TODO: handle exception
	// e.getMessage();
	// }
	// }
	////

//	@Test(priority = 9)
//	public void PrescriptionHistory() {
//		try {
//			Thread.sleep(4000);
//
//			String HomePageTitle = driver.getTitle();
//			// Thread.sleep(2000);
//			if (!HomePageTitle.equals("Login")) { // Check the Page title if we are reach at home page or not.
//				WebDriverWait wait = new WebDriverWait(driver, 15);
//				int ii = 0;
//				while (ii < 1) {
//					Thread.sleep(2000);
//					if (driver.findElement(By.xpath("//*[@id=\'notificationDialogCloseButton\']")).isDisplayed()) {
//						driver.findElement(By.xpath("//*[@id=\'notificationDialogCloseButton\']")).click();
//					} else {
//						ii = 1;
//					}
//				}
//				String PrescriptionHistoryTabpermission = DpModulePermission.getRow(8).getCell(1).getStringCellValue();
//				if (PrescriptionHistoryTabpermission.equals("YES")) {
//					// System.out.println("Serice Preferecnces Tab is Yes ");
//					String PrescriptionHistoryTabHTML = OrPrescriptionHistory_tab.getRow(1).getCell(3)
//							.getStringCellValue();
//					try {
//						if (driver.findElement(By.xpath(PrescriptionHistoryTabHTML)).isDisplayed()) {
//							// System.out.println("Service Preferences tab is visible");
//
//						}
//					} catch (Exception e) {
//						// TODO: handle exception
//						System.out.println("Prescription History tab is Not visible");
//						String PatientSearchFirstnameHTML = OrPatient.getRow(88).getCell(3).getStringCellValue();
//						String PatientSearchLastnameHTML = OrPatient.getRow(90).getCell(3).getStringCellValue();
//						String PatientSearchDOBHTML = OrPatient.getRow(91).getCell(3).getStringCellValue();
//						String PatientSearchHTML = OrPatient.getRow(96).getCell(3).getStringCellValue();
//
//						String PatientFirstName = DpPatient.getRow(1).getCell(1).getStringCellValue();
//						String PatientLastName = DpPatient.getRow(1).getCell(2).getStringCellValue();
//						String PatientDOB = DpPatient.getRow(1).getCell(3).getStringCellValue();
//
//						Thread.sleep(2000);
//
//						String SearchPatientHomeHTML = OrPatient.getRow(86).getCell(3).getStringCellValue();
//
//						WebElement SearchPatientHomeElement = driver.findElement(By.xpath(SearchPatientHomeHTML));
//						SearchPatientHomeElement.click();
//
//						Thread.sleep(2000);
//
//						wait.until(ExpectedConditions
//								.elementToBeClickable(driver.findElement(By.xpath(PatientSearchFirstnameHTML))));
//						WebElement PatientSearchFirstnameElement = driver
//								.findElement(By.xpath(PatientSearchFirstnameHTML));
//						PatientSearchFirstnameElement.clear();
//						PatientSearchFirstnameElement.sendKeys(PatientFirstName);
//
//						wait.until(ExpectedConditions
//								.elementToBeClickable(driver.findElement(By.xpath(PatientSearchLastnameHTML))));
//						WebElement PatientSearchLastnameElement = driver
//								.findElement(By.xpath(PatientSearchLastnameHTML));
//						PatientSearchLastnameElement.clear();
//						PatientSearchLastnameElement.sendKeys(PatientLastName);
//
//						wait.until(ExpectedConditions
//								.elementToBeClickable(driver.findElement(By.xpath(PatientSearchDOBHTML))));
//						WebElement PatientSearchDOBElement = driver.findElement(By.xpath(PatientSearchDOBHTML));
//						PatientSearchDOBElement.clear();
//						PatientSearchDOBElement.sendKeys(PatientDOB);
//
//						wait.until(ExpectedConditions
//								.elementToBeClickable(driver.findElement(By.xpath(PatientSearchHTML))));
//						WebElement PatientSearchElement = driver.findElement(By.xpath(PatientSearchHTML));
//						PatientSearchElement.click();
//
//						try {
//							Thread.sleep(3000);
//							wait.until(ExpectedConditions.elementToBeClickable(driver.findElement(
//									By.xpath("//*[@id=\'listGridDiv\']/div[1]/table/tbody/tr[1]/td[2]/a"))));
//							WebElement firstpatientrecord = driver
//									.findElement(By.xpath("//*[@id=\'listGridDiv\']/div[1]/table/tbody/tr[1]/td[2]/a"));
//							Thread.sleep(2000);
//							firstpatientrecord.click();
//						} catch (Exception ee) {
//							// TODO: handle exception
//							System.out.println("Patient Not Found for Prescription History Tab");
//						}
//					}
//
//					Thread.sleep(2000);
//
//					WebElement PrescriptionHistoryTabElement = driver.findElement(By.xpath(PrescriptionHistoryTabHTML));
//					wait.until(ExpectedConditions
//							.elementToBeClickable(driver.findElement(By.xpath(PrescriptionHistoryTabHTML))));
//					PrescriptionHistoryTabElement.click();
//
////------------------------------------------------------------------------------------------------------------------------------------------------
//					Thread.sleep(2000);
//					String AddPrescriptionHTML = OrPrescriptionHistory_tab.getRow(2).getCell(3).getStringCellValue();
//					driver.findElement(By.xpath(AddPrescriptionHTML)).click();
//					Thread.sleep(2000);
//
//					String ReveiveMethodHTML = OrPrescriptionHistory_tab.getRow(3).getCell(3).getStringCellValue();
//					String ReceiveMethod = DpPrescriptionHistory_tab.getRow(1).getCell(1).getStringCellValue();
//					wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(ReveiveMethodHTML)));
//					Select ReceivedMethod = new Select(driver.findElement(By.xpath(ReveiveMethodHTML)));
//					ReceivedMethod.selectByVisibleText(ReceiveMethod);
//					// System.out.println(date1);
//					try {
//						Thread.sleep(3000);
//					} catch (InterruptedException e1) {
//						// TODO Auto-generated catch block
//						e1.printStackTrace();
//					}
//					String ReceivedDateHTML = OrPrescriptionHistory_tab.getRow(4).getCell(3).getStringCellValue();
//					String ReceivedDate = DpPrescriptionHistory_tab.getRow(1).getCell(2).getStringCellValue();
//					// System.out.println(ReceivedDate);
//					wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(ReceivedDateHTML)));
//					WebElement pharmacyRxRecDateelement = driver.findElement(By.xpath(ReceivedDateHTML));
//					pharmacyRxRecDateelement.clear();
//					pharmacyRxRecDateelement.sendKeys(ReceivedDate);
//
//					try {
//						Thread.sleep(1000);
//					} catch (InterruptedException e2) {
//						// TODO Auto-generated catch block
//						e2.printStackTrace();
//					}
//
//					String RxNeedbyDateHTML = OrPrescriptionHistory_tab.getRow(5).getCell(3).getStringCellValue();
//					String RxNeedbydate = DpPrescriptionHistory_tab.getRow(1).getCell(3).getStringCellValue();
//					// System.out.println(RxNeedbydate);
//
//					wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(RxNeedbyDateHTML)));
//					WebElement rxNeedbyDateelement = driver.findElement(By.xpath(RxNeedbyDateHTML));
//					rxNeedbyDateelement.clear();
//					rxNeedbyDateelement.sendKeys(RxNeedbydate);
//					try {
//						Thread.sleep(1000);
//					} catch (InterruptedException e1) {
//						// TODO Auto-generated catch block
//						e1.printStackTrace();
//					}
//					String PharmacyStoreHTML = OrPrescriptionHistory_tab.getRow(23).getCell(3).getStringCellValue();
//					String PharmacyStore = DpPrescriptionHistory_tab.getRow(1).getCell(5).getStringCellValue();
//					Select PharmacyStoreElemnt = new Select(driver.findElement(By.xpath(PharmacyStoreHTML)));
//					PharmacyStoreElemnt.selectByVisibleText(PharmacyStore);
//					try {
//						Thread.sleep(1000);
//					} catch (InterruptedException e1) {
//						// TODO Auto-generated catch block
//						e1.printStackTrace();
//					}
//					String RxDrugTypeHTML = OrPrescriptionHistory_tab.getRow(6).getCell(3).getStringCellValue();
//					wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(RxDrugTypeHTML)));
//					Select rxDrugTypeelement = new Select(driver.findElement(By.xpath(RxDrugTypeHTML)));
//					rxDrugTypeelement.selectByVisibleText("Specialty");
//					try {
//						Thread.sleep(1000);
//					} catch (InterruptedException e1) {
//						// TODO Auto-generated catch block
//						e1.printStackTrace();
//					}
//					String PrescriberdruglinkHTML = OrPrescriptionHistory_tab.getRow(7).getCell(3).getStringCellValue();
//					wait.until(ExpectedConditions.elementToBeClickable(By.xpath(PrescriberdruglinkHTML)));
//					WebElement addprescriberdrugelement = driver.findElement(By.xpath(PrescriberdruglinkHTML));
//					((JavascriptExecutor) driver)
//							.executeScript("window.scrollTo(0," + addprescriberdrugelement.getLocation().y + ")");
//					addprescriberdrugelement.click();
//					try {
//						Thread.sleep(1000);
//					} catch (InterruptedException e2) {
//						// TODO Auto-generated catch block
//						e2.printStackTrace();
//					}
//					String NDCHTML = OrPrescriptionHistory_tab.getRow(8).getCell(3).getStringCellValue();
//					String NDC = DpPrescriptionHistory_tab.getRow(1).getCell(16).getStringCellValue();
//					wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath(NDCHTML)));
//					WebElement NDCSearchboxelement = driver.findElement(By.xpath(NDCHTML));
//					NDCSearchboxelement.clear();
//					NDCSearchboxelement.sendKeys(NDC);
//					try {
//						Thread.sleep(1000);
//					} catch (InterruptedException e1) {
//						// TODO Auto-generated catch block
//						e1.printStackTrace();
//					}
//					String SearchDrugHTML = OrPrescriptionHistory_tab.getRow(9).getCell(3).getStringCellValue();
//					wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath(SearchDrugHTML)));
//					driver.findElement(By.xpath(SearchDrugHTML)).click();
//					try {
//						Thread.sleep(1000);
//					} catch (InterruptedException e1) {
//						// TODO Auto-generated catch block
//						e1.printStackTrace();
//					}
//
//					String drugradioHTML = OrPrescriptionHistory_tab.getRow(10).getCell(3).getStringCellValue();
//					wait.until(ExpectedConditions.elementToBeClickable(By.xpath(drugradioHTML)));
//					driver.findElement(By.xpath(drugradioHTML)).click();
//					try {
//						Thread.sleep(2000);
//					} catch (InterruptedException e1) {
//						// TODO Auto-generated catch block
//						e1.printStackTrace();
//					}
//					String PrescribedQuantityHTML = OrPrescriptionHistory_tab.getRow(11).getCell(3)
//							.getStringCellValue();
//					int PrescribedQuantityint = (int) DpPrescriptionHistory_tab.getRow(1).getCell(6)
//							.getNumericCellValue();
//					String PrescribedQuantity = String.valueOf(PrescribedQuantityint);
//					WebElement prescribeQtyelement = driver.findElement(By.xpath(PrescribedQuantityHTML));
//					((JavascriptExecutor) driver)
//							.executeScript("window.scrollTo(0," + prescribeQtyelement.getLocation().y + ")");
//					prescribeQtyelement.sendKeys(PrescribedQuantity);
//
//					// driver.findElement(By.id("dispensedQty")).sendKeys("1");
//
//					String PHRxNumberHTML = OrPrescriptionHistory_tab.getRow(12).getCell(3).getStringCellValue();
//					String PHRxNumber = DpPrescriptionHistory_tab.getRow(1).getCell(8).getStringCellValue();
//					WebElement phrxidelement = driver.findElement(By.xpath(PHRxNumberHTML));
//					((JavascriptExecutor) driver)
//							.executeScript("window.scrollTo(0," + phrxidelement.getLocation().y + ")");
//					phrxidelement.sendKeys(PHRxNumber);
//
//					String DaySupplyHTML = OrPrescriptionHistory_tab.getRow(13).getCell(3).getStringCellValue();
//					int DaySupplyint = (int) DpPrescriptionHistory_tab.getRow(1).getCell(9).getNumericCellValue();
//					String DaySupply = String.valueOf(DaySupplyint);
//					WebElement daysupplyelement = driver.findElement(By.xpath(DaySupplyHTML));
//					((JavascriptExecutor) driver)
//							.executeScript("window.scrollTo(0," + daysupplyelement.getLocation().y + ")");
//					daysupplyelement.sendKeys(DaySupply);
//
//					String DirectionsHTML = OrPrescriptionHistory_tab.getRow(14).getCell(3).getStringCellValue();
//					String Direction = DpPrescriptionHistory_tab.getRow(1).getCell(10).getStringCellValue();
//					WebElement directionelement = driver.findElement(By.xpath(DirectionsHTML));
//					((JavascriptExecutor) driver)
//							.executeScript("window.scrollTo(0," + directionelement.getLocation().y + ")");
//					directionelement.sendKeys(Direction);
//
//					String RefillsHTML = OrPrescriptionHistory_tab.getRow(15).getCell(3).getStringCellValue();
//					int Refillint = (int) DpPrescriptionHistory_tab.getRow(1).getCell(11).getNumericCellValue();
//					String Refill = String.valueOf(Refillint);
//					WebElement refillelement = driver.findElement(By.xpath(RefillsHTML));
//					((JavascriptExecutor) driver)
//							.executeScript("window.scrollTo(0," + refillelement.getLocation().y + ")");
//					refillelement.sendKeys(Refill);
//
//					// driver.findElement(By.id("fillNumber")).sendKeys("0");
//
//					// Find an element
//					String AddPrescriberlinkHTML = OrPrescriptionHistory_tab.getRow(16).getCell(3).getStringCellValue();
//					WebElement elementToClickelement = driver.findElement(By.xpath(AddPrescriberlinkHTML));
//
//					// Scroll the browser to the element's Y position
//
//					((JavascriptExecutor) driver)
//							.executeScript("window.scrollTo(0," + elementToClickelement.getLocation().y + ")");
//
//					// Click the element
//
//					elementToClickelement.click();
//					// wait.until(ExpectedConditions.elementToBeClickable(By.name("addPrescriber")));
//					// driver.findElement(By.name("addPrescriber")).click();
//					String PreWindowHandle = driver.getWindowHandle();
//					for (String winHandle : driver.getWindowHandles()) {
//						driver.switchTo().window(winHandle);
//						driver.manage().window().maximize();
//					}
//					try {
//						Thread.sleep(2000);
//					} catch (InterruptedException e1) {
//						// TODO Auto-generated catch block
//						e1.printStackTrace();
//					}
//					String FirstPrescriberonlistHTML = OrPrescriptionHistory_tab.getRow(17).getCell(3)
//							.getStringCellValue();
//					wait.until(ExpectedConditions.elementToBeClickable(By.xpath(FirstPrescriberonlistHTML)));
//					driver.findElement(By.xpath(FirstPrescriberonlistHTML)).click();
//					try {
//						Thread.sleep(2000);
//					} catch (InterruptedException e) {
//						// TODO Auto-generated catch block
//						e.printStackTrace();
//					}
//					String SaveddressPopupHTML = OrPrescriptionHistory_tab.getRow(18).getCell(3).getStringCellValue();
//					wait.until(ExpectedConditions.elementToBeClickable(By.xpath(SaveddressPopupHTML)));
//					driver.findElement(By.xpath(SaveddressPopupHTML)).click();
//
//					driver.switchTo().window(PreWindowHandle);
//					try {
//						Thread.sleep(1000);
//					} catch (InterruptedException e) {
//						// TODO Auto-generated catch block
//						e.printStackTrace();
//					}
//
//					String RxTypeHTML = OrPrescriptionHistory_tab.getRow(19).getCell(3).getStringCellValue();
//					String RxType = DpPrescriptionHistory_tab.getRow(1).getCell(13).getStringCellValue();
//					wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(RxTypeHTML)));
//					Select rxTherapyTypeelement = new Select(driver.findElement(By.xpath(RxTypeHTML)));
//					rxTherapyTypeelement.selectByVisibleText(RxType);
//					try {
//						Thread.sleep(1000);
//					} catch (InterruptedException e) {
//						// TODO Auto-generated catch block
//						e.printStackTrace();
//					}
//
//					String RxStatusHTML = OrPrescriptionHistory_tab.getRow(20).getCell(3).getStringCellValue();
//					String RxStatus = DpPrescriptionHistory_tab.getRow(1).getCell(14).getStringCellValue();
//					wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(RxStatusHTML)));
//					Select statuselement = new Select(driver.findElement(By.xpath(RxStatusHTML)));
//					statuselement.selectByVisibleText(RxStatus);
//					try {
//						Thread.sleep(1000);
//					} catch (InterruptedException e) {
//						// TODO Auto-generated catch block
//						e.printStackTrace();
//					}
//
//					String RxReasonHTML = OrPrescriptionHistory_tab.getRow(21).getCell(3).getStringCellValue();
//					String RxReason = DpPrescriptionHistory_tab.getRow(1).getCell(15).getStringCellValue();
//					wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(RxReasonHTML)));
//					Select statusReason = new Select(driver.findElement(By.xpath(RxReasonHTML)));
//					statusReason.selectByVisibleText(RxReason);
//					try {
//						Thread.sleep(1000);
//					} catch (InterruptedException e) {
//						// TODO Auto-generated catch block
//						e.printStackTrace();
//					}
//					String SaveHTML = OrPrescriptionHistory_tab.getRow(22).getCell(3).getStringCellValue();
//					wait.until(ExpectedConditions.elementToBeClickable(By.xpath(SaveHTML)));
//					driver.findElement(By.xpath(SaveHTML)).click();
//					Thread.sleep(2000);
//					System.out.println("Prescription is added With " + PHRxNumber + " Number");
////------------------------------------------------------------------------------------------------------------------------------------------------
//				} else {
//					System.out.println("Prescription History Tab permission is NO");
//				}
//
//			} else {
//
//				System.out.println("Login is not done");
//			}
//
//		} catch (Exception e) {
//			// TODO: handle exception
//			System.out.println(e.getMessage());
//		}
//
//	}
//
	@Test(priority = 8)
	public void Case() throws InterruptedException {
		test = report.startTest("Case Management");

		String HomePageTitle = driver.getTitle();
		
		// Thread.sleep(2000);
		if (!HomePageTitle.equals("Login")) { // Check the Page title if we are reach at home page or not.
			WebDriverWait wait = new WebDriverWait(driver, 15);
			int ii = 0;
			while (ii < 1) {
				Thread.sleep(2000);
				if (driver.findElement(By.xpath("//*[@id=\'notificationDialogCloseButton\']")).isDisplayed()) {
					driver.findElement(By.xpath("//*[@id=\'notificationDialogCloseButton\']")).click();
				} else {
					ii = 1;
				}
			}
			String CasePermision = DpModulePermission.getRow(9).getCell(1).getStringCellValue();
			if (CasePermision.equals("YES")) {
				// System.out.println("Service Preferences Tab is Yes ");
				String CaseManagementTab = OrCaseManagement_tab.getRow(1).getCell(3).getStringCellValue();
				try {
					if (driver.findElement(By.xpath(CaseManagementTab)).isDisplayed()) {
						// System.out.println("Service Preferences tab is visible");

					}
				} catch (Exception e) {
					// TODO: handle exception
					System.out.println("Case Management Tab is Not visible");
					String PatientSearchFirstnameHTML = OrPatient.getRow(88).getCell(3).getStringCellValue();
					String PatientSearchLastnameHTML = OrPatient.getRow(90).getCell(3).getStringCellValue();
					String PatientSearchDOBHTML = OrPatient.getRow(91).getCell(3).getStringCellValue();
					String PatientSearchHTML = OrPatient.getRow(96).getCell(3).getStringCellValue();

					String PatientFirstName = DpPatient.getRow(1).getCell(1).getStringCellValue();
					String PatientLastName = DpPatient.getRow(1).getCell(2).getStringCellValue();
					String PatientDOB = DpPatient.getRow(1).getCell(3).getStringCellValue();

					Thread.sleep(2000);

					String SearchPatientHomeHTML = OrPatient.getRow(86).getCell(3).getStringCellValue();

					WebElement SearchPatientHomeElement = driver.findElement(By.xpath(SearchPatientHomeHTML));
					SearchPatientHomeElement.click();

					Thread.sleep(2000);

					wait.until(ExpectedConditions
							.elementToBeClickable(driver.findElement(By.xpath(PatientSearchFirstnameHTML))));
					WebElement PatientSearchFirstnameElement = driver.findElement(By.xpath(PatientSearchFirstnameHTML));
					PatientSearchFirstnameElement.clear();
					PatientSearchFirstnameElement.sendKeys(PatientFirstName);

					wait.until(ExpectedConditions
							.elementToBeClickable(driver.findElement(By.xpath(PatientSearchLastnameHTML))));
					WebElement PatientSearchLastnameElement = driver.findElement(By.xpath(PatientSearchLastnameHTML));
					PatientSearchLastnameElement.clear();
					PatientSearchLastnameElement.sendKeys(PatientLastName);

					wait.until(ExpectedConditions
							.elementToBeClickable(driver.findElement(By.xpath(PatientSearchDOBHTML))));
					WebElement PatientSearchDOBElement = driver.findElement(By.xpath(PatientSearchDOBHTML));
					PatientSearchDOBElement.clear();
					PatientSearchDOBElement.sendKeys(PatientDOB);

					wait.until(
							ExpectedConditions.elementToBeClickable(driver.findElement(By.xpath(PatientSearchHTML))));
					WebElement PatientSearchElement = driver.findElement(By.xpath(PatientSearchHTML));
					PatientSearchElement.click();

					try {
						Thread.sleep(3000);
						wait.until(ExpectedConditions.elementToBeClickable(driver
								.findElement(By.xpath("//*[@id=\'listGridDiv\']/div[1]/table/tbody/tr[1]/td[2]/a"))));
						WebElement firstpatientrecord = driver
								.findElement(By.xpath("//*[@id=\'listGridDiv\']/div[1]/table/tbody/tr[1]/td[2]/a"));
						Thread.sleep(2000);
						firstpatientrecord.click();
					} catch (Exception ee) {
						// TODO: handle exception
						System.out.println("Patient Not Found for Case Management Tab");
					}
				}

				Thread.sleep(2000);
				// ======================================== CREATE CASE
				// ================================================================================

				String CaseManagementTabHTML = OrCaseManagement_tab.getRow(1).getCell(3).getStringCellValue();
				wait.until(ExpectedConditions.elementToBeClickable(By.xpath(CaseManagementTabHTML)));
				driver.findElement(By.xpath(CaseManagementTabHTML)).click();

				Thread.sleep(2000);

				try {
					String HistoryHTML = OrCaseManagement_tab.getRow(9).getCell(3).getStringCellValue();

					driver.findElement(By.xpath(HistoryHTML)).click();
				} catch (Exception e) {
					// TODO: handle exception
					String AddCaseHTML = OrCaseManagement_tab.getRow(2).getCell(3).getStringCellValue();

					WebElement Addcase = driver.findElement(By.xpath(AddCaseHTML));
					((JavascriptExecutor) driver).executeScript("window.scrollTo(0," + Addcase.getLocation().y + ")");
					Addcase.click();

				}

				Thread.sleep(2000);

				String PharmacyStoreHTML = OrCaseManagement_tab.getRow(3).getCell(3).getStringCellValue();
				String PharmacyStore = DpCaseManagement_tab.getRow(1).getCell(0).getStringCellValue();
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(PharmacyStoreHTML)));
				Select pharmacyStore = new Select(driver.findElement(By.xpath(PharmacyStoreHTML)));
				pharmacyStore.selectByVisibleText(PharmacyStore);

				Thread.sleep(2000);

				String TherapeuticHTML = OrCaseManagement_tab.getRow(4).getCell(3).getStringCellValue();
				String Therapeutic = DpCaseManagement_tab.getRow(1).getCell(1).getStringCellValue();
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(TherapeuticHTML)));
				Select therapeuticProgram = new Select(driver.findElement(By.xpath(TherapeuticHTML)));
				therapeuticProgram.selectByVisibleText(Therapeutic);

				Thread.sleep(3000);

				String RxProcessingHTML = OrCaseManagement_tab.getRow(5).getCell(3).getStringCellValue();
				wait.until(ExpectedConditions.elementToBeClickable(By.xpath(RxProcessingHTML)));
				driver.findElement(By.xpath(RxProcessingHTML)).click();

				Thread.sleep(1000);

				String CareplanHTML = OrCaseManagement_tab.getRow(6).getCell(3).getStringCellValue();
				String Careplan = DpCaseManagement_tab.getRow(1).getCell(2).getStringCellValue();
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(CareplanHTML)));
				Select selectCarePlan = new Select(driver.findElement(By.xpath(CareplanHTML)));
				selectCarePlan.selectByVisibleText(Careplan);

				String NewRxHTML = OrCaseManagement_tab.getRow(7).getCell(3).getStringCellValue();
				driver.findElement(By.xpath(NewRxHTML)).click();

				String CreateCaseHTML = OrCaseManagement_tab.getRow(10).getCell(3).getStringCellValue();
				driver.findElement(By.xpath(CreateCaseHTML)).click();
				try {
					Thread.sleep(2000);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				try {
					if (driver.findElement(By.xpath("//*[@id=\'sametccareplandialog\']/div/div/div[3]/button[1]"))
							.isDisplayed()) {
						driver.findElement(By.xpath("//*[@id=\'sametccareplandialog\']/div/div/div[3]/button[1]"))
								.click();
						System.out.println("Case Added Duplicate");
					} else {
						System.out.println("Case Added new");
					}

				} catch (Exception e) {
					// TODO: handle exception
				}
				String CaseIDHTML = OrCaseManagement_tab.getRow(11).getCell(3).getStringCellValue();
				String CaseId = driver.findElement(By.xpath(CaseIDHTML)).getText();
				System.out.println(CaseId);
				test.log(LogStatus.INFO, "CaseId: "+CaseId);
				// ================================================================================================================================================

				// =============================================== ADD NEW PRESCRIPTION
				// ===========================================================================

				try {

					String IntakeWorkflowHTML = OrCaseManagement_tab.getRow(12).getCell(6).getStringCellValue();
					wait.until(ExpectedConditions.elementToBeClickable(By.className(IntakeWorkflowHTML)));
					Thread.sleep(2000);
					WebElement IntakeWorkflowElement = driver.findElement(By.className(IntakeWorkflowHTML));
					IntakeWorkflowElement.click();
					Thread.sleep(2000);
					WebElement PrescriptionIntakeActivity = driver.findElement(By.linkText("Prescription Intake"));
					((JavascriptExecutor) driver).executeScript("window.scrollTo(0," + PrescriptionIntakeActivity.getLocation().y + ")");
					PrescriptionIntakeActivity.click();
					/*
					 * wait.until(ExpectedConditions.elementToBeClickable(By.xpath(
					 * "//*[@id=\'accordion\']/div[2]/div[1]/h4/a")));
					 * driver.findElement(By.xpath("//*[@id=\'accordion\']/div[2]/div[1]/h4/a")).
					 * click();
					 */

					Thread.sleep(2000);

					wait.until(ExpectedConditions.elementToBeClickable(By.partialLinkText("Add Prescription")));
					WebElement AddprescriptionLinkElement = driver.findElement(By.partialLinkText("Add Prescription"));
					AddprescriptionLinkElement.click();

					try {
						Thread.sleep(2000);
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					String winHandleBefore = driver.getWindowHandle();
					for (String winHandle : driver.getWindowHandles()) {
						driver.switchTo().window(winHandle);
						driver.manage().window().maximize();

					}
					String ReveiveMethodHTML = OrPrescriptionHistory_tab.getRow(3).getCell(3).getStringCellValue();
					String ReceiveMethod = DpCaseManagement_tab.getRow(1).getCell(3).getStringCellValue();
					wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(ReveiveMethodHTML)));
					Select ReceivedMethod = new Select(driver.findElement(By.xpath(ReveiveMethodHTML)));
					ReceivedMethod.selectByVisibleText(ReceiveMethod);
					// System.out.println(date1);
					try {
						Thread.sleep(3000);
					} catch (InterruptedException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					String ReceivedDateHTML = OrPrescriptionHistory_tab.getRow(4).getCell(3).getStringCellValue();
					String ReceivedDate = DpCaseManagement_tab.getRow(1).getCell(4).getStringCellValue();
					// System.out.println(ReceivedDate);
					wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(ReceivedDateHTML)));
					WebElement pharmacyRxRecDateelement = driver.findElement(By.xpath(ReceivedDateHTML));
					pharmacyRxRecDateelement.clear();
					pharmacyRxRecDateelement.sendKeys(ReceivedDate);

					try {
						Thread.sleep(1000);
					} catch (InterruptedException e2) {
						// TODO Auto-generated catch block
						e2.printStackTrace();
					}

					String RxNeedbyDateHTML = OrPrescriptionHistory_tab.getRow(5).getCell(3).getStringCellValue();
					String RxNeedbydate = DpCaseManagement_tab.getRow(1).getCell(5).getStringCellValue();
					// System.out.println(RxNeedbydate);
					wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(RxNeedbyDateHTML)));
					WebElement rxNeedbyDateelement = driver.findElement(By.xpath(RxNeedbyDateHTML));
					rxNeedbyDateelement.clear();
					rxNeedbyDateelement.sendKeys(RxNeedbydate);
					try {
						Thread.sleep(1000);
					} catch (InterruptedException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					String RxDrugTypeHTML = OrPrescriptionHistory_tab.getRow(6).getCell(3).getStringCellValue();
					wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(RxDrugTypeHTML)));
					Select rxDrugTypeelement = new Select(driver.findElement(By.xpath(RxDrugTypeHTML)));
					rxDrugTypeelement.selectByValue("SPECIALTY");
					try {
						Thread.sleep(1000);
					} catch (InterruptedException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					String PrescriberdruglinkHTML = OrPrescriptionHistory_tab.getRow(7).getCell(3).getStringCellValue();
					wait.until(ExpectedConditions.elementToBeClickable(By.xpath(PrescriberdruglinkHTML)));
					WebElement addprescriberdrugelement = driver.findElement(By.xpath(PrescriberdruglinkHTML));
					((JavascriptExecutor) driver)
							.executeScript("window.scrollTo(0," + addprescriberdrugelement.getLocation().y + ")");
					addprescriberdrugelement.click();
					try {
						Thread.sleep(1000);
					} catch (InterruptedException e2) {
						// TODO Auto-generated catch block
						e2.printStackTrace();
					}
					String NDCHTML = OrPrescriptionHistory_tab.getRow(8).getCell(3).getStringCellValue();
					String NDC = DpCaseManagement_tab.getRow(1).getCell(18).getStringCellValue();
					wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath(NDCHTML)));
					WebElement NDCSearchboxelement = driver.findElement(By.xpath(NDCHTML));
					NDCSearchboxelement.clear();
					NDCSearchboxelement.sendKeys(NDC);
					try {
						Thread.sleep(1000);
					} catch (InterruptedException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					String SearchDrugHTML = OrPrescriptionHistory_tab.getRow(9).getCell(3).getStringCellValue();
					wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath(SearchDrugHTML)));
					driver.findElement(By.xpath(SearchDrugHTML)).click();
					try {
						Thread.sleep(1000);
					} catch (InterruptedException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}

					String drugradioHTML = OrPrescriptionHistory_tab.getRow(10).getCell(3).getStringCellValue();
					wait.until(ExpectedConditions.elementToBeClickable(By.xpath(drugradioHTML)));
					driver.findElement(By.xpath(drugradioHTML)).click();
					try {
						Thread.sleep(2000);
					} catch (InterruptedException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}

					String PrescribedQuantityHTML = OrPrescriptionHistory_tab.getRow(11).getCell(3)
							.getStringCellValue();
					int PrescribedQuantityint = (int) DpCaseManagement_tab.getRow(1).getCell(8).getNumericCellValue();
					String PrescribedQuantity = String.valueOf(PrescribedQuantityint);
					WebElement prescribeQtyelement = driver.findElement(By.xpath(PrescribedQuantityHTML));
					((JavascriptExecutor) driver).executeScript("window.scrollTo(0," + prescribeQtyelement.getLocation().y + ")");
					prescribeQtyelement.sendKeys(PrescribedQuantity);

					String DispensedQuantityHTML = OrPrescriptionHistory_tab.getRow(24).getCell(3).getStringCellValue();
					int DispensedQuantityint = (int) DpCaseManagement_tab.getRow(1).getCell(9).getNumericCellValue();
					String DispensedQuantity = String.valueOf(DispensedQuantityint);
					WebElement DispensedQtyelement = driver.findElement(By.xpath(DispensedQuantityHTML));
					((JavascriptExecutor) driver)
							.executeScript("window.scrollTo(0," + DispensedQtyelement.getLocation().y + ")");
					DispensedQtyelement.sendKeys(DispensedQuantity);

					String PHRxNumberHTML = OrPrescriptionHistory_tab.getRow(12).getCell(3).getStringCellValue();
					String PHRxNumber = DpCaseManagement_tab.getRow(1).getCell(10).getStringCellValue();
					WebElement phrxidelement = driver.findElement(By.xpath(PHRxNumberHTML));
					((JavascriptExecutor) driver)
							.executeScript("window.scrollTo(0," + phrxidelement.getLocation().y + ")");
					phrxidelement.sendKeys(PHRxNumber);

					String DaySupplyHTML = OrPrescriptionHistory_tab.getRow(13).getCell(3).getStringCellValue();
					int DaySupplyint = (int) DpCaseManagement_tab.getRow(1).getCell(11).getNumericCellValue();
					String DaySupply = String.valueOf(DaySupplyint);
					WebElement daysupplyelement = driver.findElement(By.xpath(DaySupplyHTML));
					((JavascriptExecutor) driver)
							.executeScript("window.scrollTo(0," + daysupplyelement.getLocation().y + ")");
					daysupplyelement.sendKeys(DaySupply);

					String DirectionsHTML = OrPrescriptionHistory_tab.getRow(14).getCell(3).getStringCellValue();
					String Direction = DpCaseManagement_tab.getRow(1).getCell(12).getStringCellValue();
					WebElement directionelement = driver.findElement(By.xpath(DirectionsHTML));
					((JavascriptExecutor) driver)
							.executeScript("window.scrollTo(0," + directionelement.getLocation().y + ")");
					directionelement.sendKeys(Direction);

					String RefillsHTML = OrPrescriptionHistory_tab.getRow(15).getCell(3).getStringCellValue();
					int Refillint = (int) DpCaseManagement_tab.getRow(1).getCell(13).getNumericCellValue();
					String Refill = String.valueOf(Refillint);
					WebElement refillelement = driver.findElement(By.xpath(RefillsHTML));
					((JavascriptExecutor) driver)
							.executeScript("window.scrollTo(0," + refillelement.getLocation().y + ")");
					refillelement.sendKeys(Refill);

					String FillNumberHTML = OrPrescriptionHistory_tab.getRow(25).getCell(3).getStringCellValue();
					int Fillnumberint = (int) DpCaseManagement_tab.getRow(1).getCell(14).getNumericCellValue();
					String FillNumber = String.valueOf(Fillnumberint);
					WebElement FillNumberelement = driver.findElement(By.xpath(FillNumberHTML));
					((JavascriptExecutor) driver)
							.executeScript("window.scrollTo(0," + FillNumberelement.getLocation().y + ")");
					FillNumberelement.sendKeys(FillNumber);

					// Find an element

					String AddPrescriberlinkHTML = OrPrescriptionHistory_tab.getRow(16).getCell(3).getStringCellValue();
					WebElement elementToClickelement = driver.findElement(By.xpath(AddPrescriberlinkHTML));

					// Scroll the browser to the element's Y position

					((JavascriptExecutor) driver)
							.executeScript("window.scrollTo(0," + elementToClickelement.getLocation().y + ")");

					// Click the element

					elementToClickelement.click();
					// wait.until(ExpectedConditions.elementToBeClickable(By.name("addPrescriber")));
					// driver.findElement(By.name("addPrescriber")).click();
					String PreWindowHandle = driver.getWindowHandle();
					for (String winHandle : driver.getWindowHandles()) {
						driver.switchTo().window(winHandle);
						driver.manage().window().maximize();
					}
					try {
						Thread.sleep(2000);
					} catch (InterruptedException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					String FirstPrescriberonlistHTML = OrPrescriptionHistory_tab.getRow(17).getCell(3)
							.getStringCellValue();
					wait.until(ExpectedConditions.elementToBeClickable(By.xpath(FirstPrescriberonlistHTML)));
					driver.findElement(By.xpath(FirstPrescriberonlistHTML)).click();
					try {
						Thread.sleep(2000);
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					String SaveddressPopupHTML = OrPrescriptionHistory_tab.getRow(18).getCell(3).getStringCellValue();
					wait.until(ExpectedConditions.elementToBeClickable(By.xpath(SaveddressPopupHTML)));
					driver.findElement(By.xpath(SaveddressPopupHTML)).click();

					driver.switchTo().window(PreWindowHandle);
					try {
						Thread.sleep(1000);
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					String RxTypeHTML = OrPrescriptionHistory_tab.getRow(19).getCell(3).getStringCellValue();
					String RxType = DpCaseManagement_tab.getRow(1).getCell(15).getStringCellValue();
					wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(RxTypeHTML)));
					Select rxTherapyTypeelement = new Select(driver.findElement(By.xpath(RxTypeHTML)));
					rxTherapyTypeelement.selectByVisibleText(RxType);
					try {
						Thread.sleep(1000);
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}

					String RxStatusHTML = OrPrescriptionHistory_tab.getRow(20).getCell(3).getStringCellValue();
					String RxStatus = DpCaseManagement_tab.getRow(1).getCell(16).getStringCellValue();
					wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(RxStatusHTML)));
					Select statuselement = new Select(driver.findElement(By.xpath(RxStatusHTML)));
					statuselement.selectByVisibleText(RxStatus);
					try {
						Thread.sleep(1000);
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}

					String RxReasonHTML = OrPrescriptionHistory_tab.getRow(21).getCell(3).getStringCellValue();
					String RxReason = DpCaseManagement_tab.getRow(1).getCell(17).getStringCellValue();
					wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(RxReasonHTML)));
					Select statusReason = new Select(driver.findElement(By.xpath(RxReasonHTML)));
					statusReason.selectByVisibleText(RxReason);
					try {
						Thread.sleep(1000);
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					String SaveHTML = OrPrescriptionHistory_tab.getRow(22).getCell(3).getStringCellValue();
					wait.until(ExpectedConditions.elementToBeClickable(By.xpath(SaveHTML)));
					driver.findElement(By.xpath(SaveHTML)).click();
					Thread.sleep(2000);
					System.out.println("Prescription is added With " + PHRxNumber + " Number");
					driver.switchTo().window(winHandleBefore);

				} catch (Exception e) {
					// TODO: handle exception
					System.out.println(e.getMessage());
				}
				// ================================================================================================================================================

				// ============================================== POS Activity
				// ====================================================================================

				Thread.sleep(4000);

				WebElement POSWorkflowElement = driver.findElement(By.className("seleCaseLeftMenuPointOfSale"));
				((JavascriptExecutor) driver)
						.executeScript("window.scrollTo(0," + POSWorkflowElement.getLocation().y + ")");
				wait.until(ExpectedConditions.elementToBeClickable(By.className("seleCaseLeftMenuPointOfSale")));
				Thread.sleep(2000);
				POSWorkflowElement.click();
				Thread.sleep(3000);

				try {
					WebElement POSIntakeActivity = driver.findElement(By.partialLinkText("Confirmation of Order"));
					POSIntakeActivity.click();
					Thread.sleep(2000);

					if (DpCaseManagement_tab.getRow(1).getCell(16).getStringCellValue().equalsIgnoreCase("filled")) {

						driver.findElement(By.xpath(
								"//*[@id=\"activityConfirmation of Order\"]/div/div/div[2]/div/div[2]/div[4]/div[1]/div[1]"))
								.click();
						Select OrderSoldMethod = new Select(
								driver.findElement(By.xpath("//*[@id=\"orderSoldMethod0\"]")));
						OrderSoldMethod.selectByVisibleText("Picked-up at Pharmacy");
						Thread.sleep(1000);
						WebElement OrderSoldDate = driver.findElement(By.xpath("//*[@id=\"orderSoldDate0\"]"));
						OrderSoldDate.clear();
						OrderSoldDate.sendKeys("02/04/2019");
						Thread.sleep(1000);
						WebElement OrderSoldTime = driver.findElement(By.xpath("//*[@id=\"orderSoldTime0\"]"));
						OrderSoldTime.clear();
						OrderSoldTime.sendKeys("12:02 AM");
						WebElement SaveAll = driver.findElement(By.xpath("//*[@class='save-btn']/*[1]"));
						((JavascriptExecutor) driver)
								.executeScript("window.scrollTo(0," + SaveAll.getLocation().y + ")");
						SaveAll.click();

					} else {
						System.out.println("Prescription is not a Filled");
					}

				} catch (Exception e) {
					// TODO: handle exception
					System.out.println(e.getMessage());
				}
				Thread.sleep(3000);
				// ================================================================================================================================================
				// ================================== Complete the all workflow
				// ===================================================================================

				List<WebElement> workflowcount = driver
						.findElements(By.xpath("//*[@id=\"caseForm\"]/div/div[1]/ul/li"));
				System.out.println("Workflow count is " + workflowcount.size());
				for (int j = 1; j <= workflowcount.size(); j++) {
					Thread.sleep(5000);
					WebElement workflow = driver.findElement(By.xpath("//form/div[1]/div[1]/ul[1]/li[" + j + "]/a[1]"));
					((JavascriptExecutor) driver).executeScript("window.scrollTo(0," + workflow.getLocation().y + ")");
					((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", workflow);
					wait.until(ExpectedConditions.elementToBeClickable(
							driver.findElement(By.xpath("//form/div[1]/div[1]/ul[1]/li[" + j + "]/a[1]"))));
					Thread.sleep(3000);
					workflow.click();
					Thread.sleep(4000);
					List<WebElement> elements = driver.findElements(By.xpath("//*[contains(@id,'activtyRadioNA')]"));
					System.out.println(driver.findElement(By.xpath("//*[@id=\'workflowScreen\']/h3")).getText()
							+ "Number of elements:" + elements.size());
					for (int i = 0; i < elements.size(); i++) {
						String coreid = elements.get(i).getAttribute("id");
						// System.out.println("Core id is "+coreid);
						String[] part = coreid.split("(?<=\\D)(?=\\d)");
						// System.out.println(part[0]);
						// System.out.println(part[1]);
						// System.out.println("Radio button text:" +
						// elements.get(i).getAttribute("id"));
						try {
							WebElement ALLNAActivityRadio = driver
									.findElement(By.xpath("//input[@id='activtyRadioNA-" + part[1] + "']"));
							((JavascriptExecutor) driver)
									.executeScript("window.scrollTo(0," + ALLNAActivityRadio.getLocation().y + ")");
							Thread.sleep(2000);
							ALLNAActivityRadio.click();
							Thread.sleep(2000);
							if (driver.findElement(By.partialLinkText("Prescription Intake")).isDisplayed()) {
								WebElement PrescriptionIntakeActivity = driver
										.findElement(By.linkText("Prescription Intake"));
								// System.out.println(PrescriptionIntakeActivity);
								String prescriptionactivitycoreid = PrescriptionIntakeActivity.getAttribute("href");
								// System.out.println("href is "+ prescriptionactivitycoreid);
								String[] linkpart = prescriptionactivitycoreid.split("(?<=\\D)(?=\\d)");
								// System.out.println(linkpart[0]);
								// System.out.println(linkpart[1]);
								String lastOne = linkpart[linkpart.length - 1];
								if (lastOne.equals(part[1])) {
									WebElement CompleteActivityRadio = driver.findElement(
											By.xpath("//input[@id='activtyRadioComplete-" + lastOne + "']"));
									((JavascriptExecutor) driver).executeScript(
											"window.scrollTo(0," + CompleteActivityRadio.getLocation().y + ")");
									wait.until(ExpectedConditions.elementToBeClickable(CompleteActivityRadio));
									Thread.sleep(2000);
									CompleteActivityRadio.click();
								} else {
									WebElement NAActivityRadio = driver
											.findElement(By.xpath("//input[@id='activtyRadioNA-" + part[1] + "']"));
									((JavascriptExecutor) driver).executeScript(
											"window.scrollTo(0," + NAActivityRadio.getLocation().y + ")");
									wait.until(ExpectedConditions.elementToBeClickable(NAActivityRadio));
									Thread.sleep(2000);
									NAActivityRadio.click();
								}
							}
						} catch (Exception e) {
							// TODO: handle exception
						}
						try {
							if (driver.findElement(By.partialLinkText("Confirmation of Order")).isDisplayed()) {
								WebElement ConfirmoforderActivity = driver
										.findElement(By.partialLinkText("Confirmation of Order"));
								// System.out.println(PrescriptionIntakeActivity);
								String confirmorderactivitycoreid = ConfirmoforderActivity.getAttribute("href");
								// System.out.println("href is "+ prescriptionactivitycoreid);
								String[] linkpart = confirmorderactivitycoreid.split("(?<=\\D)(?=\\d)");
								// System.out.println(linkpart[0]);
								// System.out.println(linkpart[1]);
								String lastOne = linkpart[linkpart.length - 1];
								if (lastOne.equals(part[1])) {
									WebElement CompleteActivityRadio = driver.findElement(
											By.xpath("//input[@id='activtyRadioComplete-" + lastOne + "']"));
									((JavascriptExecutor) driver).executeScript(
											"window.scrollTo(0," + CompleteActivityRadio.getLocation().y + ")");
									wait.until(ExpectedConditions.elementToBeClickable(CompleteActivityRadio));
									CompleteActivityRadio.click();
								} else {
									WebElement NAActivityRadio = driver
											.findElement(By.xpath("//input[@id='activtyRadioNA-" + part[1] + "']"));
									((JavascriptExecutor) driver).executeScript(
											"window.scrollTo(0," + NAActivityRadio.getLocation().y + ")");
									wait.until(ExpectedConditions.elementToBeClickable(NAActivityRadio));
									NAActivityRadio.click();
								}
							}
						} catch (Exception e) {
							// TODO: handle exception
						}
					}
					WebElement YesAll = driver.findElement(By.xpath("//input[@id='statusTrue']"));
					((JavascriptExecutor) driver).executeScript("window.scrollTo(0," + YesAll.getLocation().y + ")");
					wait.until(ExpectedConditions.elementToBeClickable(YesAll));
					YesAll.click();
					WebElement SaveAll = driver.findElement(By.xpath("//*[@class='save-btn']/*[1]"));
					((JavascriptExecutor) driver).executeScript("window.scrollTo(0," + SaveAll.getLocation().y + ")");
					wait.until(ExpectedConditions.elementToBeClickable(SaveAll));
					SaveAll.click();
					if (j == workflowcount.size()) {
						System.out.println("Case Completed");
						test.log(LogStatus.INFO, "Case Completed");
					} else {
						try {
							Thread.sleep(4000);
							wait.until(ExpectedConditions.elementToBeClickable(driver
									.findElement(By.xpath("//*[@id=\"updateFollowupDate\"]/div/div/div[3]/button"))));
							driver.findElement(By.xpath("//*[@id=\"updateFollowupDate\"]/div/div/div[3]/button"))
									.click();
							Thread.sleep(4000);
							wait.until(ExpectedConditions.elementToBeClickable(driver
									.findElement(By.xpath("//*[@id='displayCaseBanner']/div/div/div[1]/button"))));
							Thread.sleep(2000);
							driver.findElement(By.xpath("//*[@id='displayCaseBanner']/div/div/div[1]/button")).click();
						} catch (Exception e) {
							System.out.println(e.getMessage());
							// TODO: handle exception
						}
					}
					/*
					 * try { if (driver.findElement(By.xpath("//*[@id=\"workflowScreen\"]/ul/li")).
					 * isDisplayed()) { System.out.println(driver.findElement(By.xpath(
					 * "//*[@id=\"workflowScreen\"]/ul/li")).getText()); } } catch (Exception e2) {
					 * // TODO: handle exception System.out.println("Completed"); }
					 */

					// System.out.println(e.getMessage());

				}
				// =============================================================================================================================================================================

				// =========================== Intake Workflow
				// =================================================================================================================================

				/*
				 * try { Thread.sleep(2000);
				 * 
				 * WebElement PrescriptionIntakeActivity =
				 * driver.findElement(By.linkText("Prescription Intake"));
				 * System.out.println(PrescriptionIntakeActivity); String
				 * prescriptionactivitycoreid = PrescriptionIntakeActivity.getAttribute("href");
				 * System.out.println("href is " + prescriptionactivitycoreid); String[]
				 * linkpart = prescriptionactivitycoreid.split("(?<=\\D)(?=\\d)"); //
				 * System.out.println(linkpart[0]); // System.out.println(linkpart[1]); String
				 * lastOne = linkpart[linkpart.length - 1]; // System.out.println(
				 * "last index is " + lastOne); List<WebElement> elements =
				 * driver.findElements(By.xpath("//*[contains(@id,'activtyRadioNA')]"));
				 * System.out.println("Number of elements:" + elements.size());
				 * 
				 * for (int i = 0; i < elements.size(); i++) { String coreid =
				 * elements.get(i).getAttribute("id"); //
				 * System.out.println("Core id is "+coreid); String[] part =
				 * coreid.split("(?<=\\D)(?=\\d)"); System.out.println(part[0]); //
				 * System.out.println(part[1]); // System.out.println("Radio button text:" + //
				 * elements.get(i).getAttribute("id"));
				 * 
				 * if (lastOne.equals(part[1])) { WebElement CompleteActivityRadio = driver
				 * .findElement(By.xpath("//input[@id='activtyRadioComplete-" + lastOne +
				 * "']")); CompleteActivityRadio.click(); ((JavascriptExecutor) driver)
				 * .executeScript("window.scrollTo(0," + CompleteActivityRadio.getLocation().y +
				 * ")"); } else { WebElement NAActivityRadio = driver
				 * .findElement(By.xpath("//input[@id='activtyRadioNA-" + part[1] + "']"));
				 * NAActivityRadio.click(); ((JavascriptExecutor) driver)
				 * .executeScript("window.scrollTo(0," + NAActivityRadio.getLocation().y + ")");
				 * }
				 * 
				 * } WebElement YesAll =
				 * driver.findElement(By.xpath("//input[@id='statusTrue']")); YesAll.click();
				 * ((JavascriptExecutor) driver).executeScript("window.scrollTo(0," +
				 * YesAll.getLocation().y + ")"); WebElement SaveAll =
				 * driver.findElement(By.xpath("//*[@class='save-btn']/*[1]")); SaveAll.click();
				 * ((JavascriptExecutor) driver).executeScript("window.scrollTo(0," +
				 * SaveAll.getLocation().y + ")");
				 * 
				 * } catch (InterruptedException e) { // TODO Auto-generated catch block
				 * System.out.println(e.getMessage()); }
				 * 
				 * //
				 * 
				 */
//				  =============================================================================
//				  =================================================================== // //
//				  ======================================================= ReFill Creation // //  ========================================================================
				Thread.sleep(3000);
				WebElement CaseHistory = driver.findElement(By.className("seleCaseHistory"));
				((JavascriptExecutor) driver).executeScript("window.scrollTo(0," + CaseHistory.getLocation().y + ")");
				wait.until(ExpectedConditions.elementToBeClickable(By.className("seleCaseHistory")));
				Thread.sleep(2000);
				CaseHistory.click();
				Thread.sleep(3000);

				try {
					Thread.sleep(2000);
				} catch (InterruptedException e) {
					// TODO
//				  Auto-generated catch block
					e.printStackTrace();
				}
				JavascriptExecutor js = (JavascriptExecutor) driver;
				js.executeScript("window.scrollTo(0, document.body.scrollHeight)");
				// Click on Radio button for create manual refill case
				WebElement Refillcase = driver.findElement(By.xpath("//*[@id=\'refillCase\']"));
				((JavascriptExecutor) driver).executeScript("window.scrollTo(0," + Refillcase.getLocation().y + ")");
				Refillcase.click();
				try {
					Thread.sleep(2000);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} // select prescription and create refill case
				driver.findElement(By.xpath("//*[@id=\'selectPrescription\']")).click();
				driver.findElement(By.xpath("//*[@id=\'prescriptionDialog\']/div/div/div[3]/a")).click();
				try {
					Thread.sleep(3000);
				} catch (InterruptedException e) { // TODO Auto-generated catch block

					e.printStackTrace();
				}
				String RefillCaseId = driver.findElement(By.xpath("//*[@id=\'caseIdInBanner\']")).getText();
				System.out.println("Refill " + RefillCaseId);
				test.log(LogStatus.INFO, "Refill Case ID " + RefillCaseId);

				Thread.sleep(3000);

//			================================================================================================================================================		
			} else {
				System.out.println("Case Management Tab permission is NO");
			}
		} else {
			System.out.println("Login is not done");
		}

	}

	@Test(priority = 9)
	public void CommunicationLog() {

		test = report.startTest("Communication Log");

		try {
			Thread.sleep(4000);
			String HomePageTitle = driver.getTitle();

			// Thread.sleep(2000);
			if (!HomePageTitle.equals("Login")) { // Check the Page title if we are reach at home page or not.
				WebDriverWait wait = new WebDriverWait(driver, 15);
				int ii = 0;
				while (ii < 1) {
					Thread.sleep(2000);
					if (driver.findElement(By.xpath("//*[@id=\'notificationDialogCloseButton\']")).isDisplayed()) {
						driver.findElement(By.xpath("//*[@id=\'notificationDialogCloseButton\']")).click();
					} else {
						ii = 1;
					}
				}

				String Communicationpermission = DpModulePermission.getRow(13).getCell(1).getStringCellValue();
				if (Communicationpermission.equals("YES")) {

					String CommunicationTabHTML = OrCommunication_Log.getRow(1).getCell(3).getStringCellValue();

					try {
						if (driver.findElement(By.xpath(CommunicationTabHTML)).isDisplayed()) {
							// System.out.println("Service Preferences tab is visible");

						}
					} catch (Exception e) {
						// TODO: handle exception
						System.out.println("Communication Log tab is Not visible");
						String PatientSearchFirstnameHTML = OrPatient.getRow(88).getCell(3).getStringCellValue();
						String PatientSearchLastnameHTML = OrPatient.getRow(90).getCell(3).getStringCellValue();
						String PatientSearchDOBHTML = OrPatient.getRow(91).getCell(3).getStringCellValue();
						String PatientSearchHTML = OrPatient.getRow(96).getCell(3).getStringCellValue();

						String PatientFirstName = DpPatient.getRow(1).getCell(1).getStringCellValue();
						String PatientLastName = DpPatient.getRow(1).getCell(2).getStringCellValue();
						String PatientDOB = DpPatient.getRow(1).getCell(3).getStringCellValue();

						Thread.sleep(2000);

						String SearchPatientHomeHTML = OrPatient.getRow(86).getCell(3).getStringCellValue();

						WebElement SearchPatientHomeElement = driver.findElement(By.xpath(SearchPatientHomeHTML));
						SearchPatientHomeElement.click();

						Thread.sleep(2000);

						wait.until(ExpectedConditions
								.elementToBeClickable(driver.findElement(By.xpath(PatientSearchFirstnameHTML))));
						WebElement PatientSearchFirstnameElement = driver
								.findElement(By.xpath(PatientSearchFirstnameHTML));
						PatientSearchFirstnameElement.clear();
						PatientSearchFirstnameElement.sendKeys(PatientFirstName);

						wait.until(ExpectedConditions
								.elementToBeClickable(driver.findElement(By.xpath(PatientSearchLastnameHTML))));
						WebElement PatientSearchLastnameElement = driver
								.findElement(By.xpath(PatientSearchLastnameHTML));
						PatientSearchLastnameElement.clear();
						PatientSearchLastnameElement.sendKeys(PatientLastName);

						wait.until(ExpectedConditions
								.elementToBeClickable(driver.findElement(By.xpath(PatientSearchDOBHTML))));
						WebElement PatientSearchDOBElement = driver.findElement(By.xpath(PatientSearchDOBHTML));
						PatientSearchDOBElement.clear();
						PatientSearchDOBElement.sendKeys(PatientDOB);

						wait.until(ExpectedConditions
								.elementToBeClickable(driver.findElement(By.xpath(PatientSearchHTML))));
						WebElement PatientSearchElement = driver.findElement(By.xpath(PatientSearchHTML));
						PatientSearchElement.click();

						try {
							Thread.sleep(3000);
							wait.until(ExpectedConditions.elementToBeClickable(driver.findElement(By.xpath("//*[@id=\'listGridDiv\']/div[1]/table/tbody/tr[1]/td[2]/a"))));
							WebElement firstpatientrecord = driver.findElement(By.xpath("//*[@id=\'listGridDiv\']/div[1]/table/tbody/tr[1]/td[2]/a"));
							Thread.sleep(2000);
							firstpatientrecord.click();
						} catch (Exception ee) {
							// TODO: handle exception
							System.out.println("Patient Not Found for Communication Log");
						}
					}
					
					try
					{
						Thread.sleep(3000);
						WebElement MDAuth = driver.findElement(By.xpath("/html/body/section/div[1]/div[2]/div/div[1]/div[3]/div/div/div[1]/h2/div/i"));
						wait.until(ExpectedConditions.elementToBeClickable(driver.findElement(By.xpath("/html/body/section/div[1]/div[2]/div/div[1]/div[3]/div/div/div[1]/h2/div/i"))));
						MDAuth.click();
						
						Thread.sleep(4000);
						
						
					}
					catch (Exception e) {
						// TODO: handle exception
						System.out.println("Patient Not Found for Communication Log");
					}

					WebElement CommunicationLogTabElement = driver.findElement(By.xpath(CommunicationTabHTML));
					wait.until(ExpectedConditions.elementToBeClickable(driver.findElement(By.xpath(CommunicationTabHTML))));
					CommunicationLogTabElement.click();
					Thread.sleep(4000);

					try {

						
						org.openqa.selenium.Alert popup = driver.switchTo().alert();
						// here you can examine the text within the alert using popup.getText();
						String alertMessage= driver.switchTo().alert().getText();
						System.out.println(alertMessage);	
				        Thread.sleep(5000);
						popup.accept();
						

						Thread.sleep(3000);
					} catch (Exception e) {
						// TODO: handle exception
						System.out.println("No Popup display");
					}

					String PatientSearchHTML = OrCommunication_Log.getRow(2).getCell(3).getStringCellValue();
					String CallType = OrCommunication_Log.getRow(3).getCell(3).getStringCellValue();
					String NotesHTML = OrCommunication_Log.getRow(4).getCell(3).getStringCellValue();
					String EmailHTML = OrCommunication_Log.getRow(6).getCell(3).getStringCellValue();
					String ReceiverHTML = OrCommunication_Log.getRow(7).getCell(3).getStringCellValue();
					String Save = OrCommunication_Log.getRow(5).getCell(3).getStringCellValue();

					String CallTypevalue = DpCommunication_Log.getRow(1).getCell(1).getStringCellValue();
					String NotesValue = DpCommunication_Log.getRow(1).getCell(2).getStringCellValue();
					String EmailValue = DpCommunication_Log.getRow(1).getCell(3).getStringCellValue();
					String ReceiverValue = DpCommunication_Log.getRow(1).getCell(4).getStringCellValue();

					
					Thread.sleep(3000);
					WebElement AddLogElement = driver.findElement(By.xpath(PatientSearchHTML));
					((JavascriptExecutor) driver).executeScript("window.scrollTo(0," + AddLogElement.getLocation().y + ")");
					AddLogElement.click();

					Thread.sleep(3000);
					Select CallTypeElement = new Select(driver.findElement(By.xpath(CallType)));
//					((JavascriptExecutor) driver).executeScript("window.scrollTo(0," + AddLogElement.getLocation().y + ")");
					CallTypeElement.selectByVisibleText(CallTypevalue);
					Thread.sleep(3000);

					WebElement EmailElement = driver.findElement(By.xpath(EmailHTML));
					EmailElement.clear();
					EmailElement.sendKeys(EmailValue);
					Thread.sleep(3000);

					Thread.sleep(3000);
					Select ReceiverElemen = new Select(driver.findElement(By.xpath(ReceiverHTML)));
					ReceiverElemen.selectByVisibleText(ReceiverValue);
					Thread.sleep(3000);

					WebElement NotesElement = driver.findElement(By.xpath(NotesHTML));
					((JavascriptExecutor) driver).executeScript("window.scrollTo(0," + NotesElement.getLocation().y + ")");
					NotesElement.clear();
					NotesElement.sendKeys(NotesValue);

					WebElement SaveClick = driver.findElement(By.xpath(Save));
					SaveClick.click();
					Thread.sleep(3000);

					Thread.sleep(2000);
					System.out.println(CallTypevalue + " Communication Log Added Successfullly");
					test.log(LogStatus.INFO, "Communication Log Added Successfullly");

					Thread.sleep(4000);

					wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id=\"loginPageLogoCommonFluidHeader1\"]")));
					Thread.sleep(2000);
					driver.findElement(By.xpath("//*[@id='loginPageLogoCommonFluidHeader1']")).click();
					Thread.sleep(2000);

				}

				else {
					System.out.println("Communication Log Permission is NO");
					test.log(LogStatus.INFO, "Communication Log Permission is NO");
				}

			} else {
				System.out.println("Login is not done");
			}
		} catch (Exception e) {
			// TODO: handle exception

			System.out.println("Communication Log Not Added Successfully");
			test.log(LogStatus.INFO, "Communication Log Not Added Successfully");
			e.getMessage();
		}
	}

	@Test(priority = 10)
	public void FaxSend() throws InterruptedException {
		test = report.startTest("Fax Send");
		Thread.sleep(4000);

		String HomePageTitle = driver.getTitle();

		// Thread.sleep(2000);
		if (HomePageTitle.equals("KloudScript")) { // Check the Page title if we are reach at home page or not.
			// System.out.println("Ctuser"+CTUser);

			int i = 0;
			while (i < 1) {
				Thread.sleep(2000);
				if (driver.findElement(By.xpath("//*[@id=\'notificationDialogCloseButton\']")).isDisplayed()) {
					driver.findElement(By.xpath("//*[@id=\'notificationDialogCloseButton\']")).click();
				} else {
					i = 1;
				}
			}
			String FaxSendpermission = DpModulePermission.getRow(11).getCell(1).getStringCellValue();

			if (FaxSendpermission.equals("YES")) {

				String receiverfaxnumber = DpFaxSend.getRow(1).getCell(2).getStringCellValue();
//					String Organization = OrFaxInbox.getRow(2).getCell(4).getStringCellValue();
//					String KSclientSearchvalue = OrFaxInbox.getRow(3).getCell(3).getStringCellValue();

				Thread.sleep(5000);
				WebElement FaxSend = driver.findElement(By.xpath("//*[@id='faxBlock']/div/div[2]/div/a[2]"));
				FaxSend.click();

				try {
					Thread.sleep(1000);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				driver.findElement(By.className("seleFaxSentSendFax")).click(); // Send Fax button click
//						
//						  wait.until(ExpectedConditions.elementToBeClickable(By.id("organization")));
//						  
//						  Select organization= new Select(driver.findElement(By.id("organization")));
//						  organization.selectByValue("2258a8c8457565100145758dedae0000");
//						  
				Thread.sleep(3000);
				try {
					Thread.sleep(3000);
				} catch (InterruptedException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}

				Select faxTemplate = new Select(driver.findElement(By.id("faxTemplate")));
				faxTemplate.selectByValue("23");
				
				WebElement To= driver.findElement(By.id("field_idx_0"));

				((JavascriptExecutor) driver).executeScript("window.scrollTo(0," + To.getLocation().y + ")");
				
				Thread.sleep(5000);
				driver.findElement(By.id("field_idx_0")).sendKeys("ToContent");
				driver.findElement(By.id("field_idx_1")).sendKeys("AttentionContent");
				driver.findElement(By.id("field_idx_2")).sendKeys("FromContent");
				
				JavascriptExecutor executor = (JavascriptExecutor)driver;


				WebElement step1 = driver.findElement(By.id("nextBtn"));

				// scroll to the element
				executor.executeScript("arguments[0].click();", step1);

				try {
				Thread.sleep(2000);
				} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				}
		
				WebElement step2 = driver.findElement(By.id("nextBtn"));

				// scroll to the element
				executor.executeScript("arguments[0].click();", step2);

				//driver.findElement(By.id("nextBtn")).click();
				
				try {
					Thread.sleep(2000);
					System.out.println("test");
					
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				Thread.sleep(2000);
				WebElement Step3 = driver.findElement(By.id("nextBtn"));

				// scroll to the element
				executor.executeScript("arguments[0].click();", Step3);

//				driver.findElement(By.id("nextBtn")).click();
				try {
					Thread.sleep(2000);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				Thread.sleep(2000);
				
//				driver.findElement(By.id("nextBtn")).click();
				try {
					Thread.sleep(2000);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

				WebElement receiverFax = driver.findElement(By.id("receiverFax"));
				receiverFax.clear();

				receiverFax.sendKeys(receiverfaxnumber);

				try {
					Thread.sleep(2000);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

				WebElement SendFax = driver.findElement(By.id("nextBtn"));
				((JavascriptExecutor) driver)
				.executeScript("window.scrollTo(0," + SendFax.getLocation().y + ")");
				SendFax.click();

				Thread.sleep(5000);

				System.out.println("Fax Send Successfully.");
				test.log(LogStatus.INFO, "Fax Send Successfully.");

				WebDriverWait wait = new WebDriverWait(driver, 15);
				Thread.sleep(2000);
				wait.until(ExpectedConditions
						.elementToBeClickable(By.xpath("//*[@id='loginPageLogoCommonFluidHeader1']")));
				driver.findElement(By.xpath("//*[@id='loginPageLogoCommonFluidHeader1']")).click();
				Thread.sleep(5000);

			}

		}

	}

	@Test(priority = 11)
	public void FaxInbox() throws InterruptedException {

		test = report.startTest("Fax Inbox");
		try {
			Thread.sleep(4000);

			String HomePageTitle = driver.getTitle();

			// Thread.sleep(2000);
			if (HomePageTitle.equals("KloudScript")) { // Check the Page title if we are reach at home page or not.
				// System.out.println("Ctuser"+CTUser);

				int i = 0;
				while (i < 1) {
					Thread.sleep(2000);
					if (driver.findElement(By.xpath("//*[@id=\'notificationDialogCloseButton\']")).isDisplayed()) {
						driver.findElement(By.xpath("//*[@id=\'notificationDialogCloseButton\']")).click();
					} else {
						i = 1;
					}
				}
				String Faxpermission = DpModulePermission.getRow(10).getCell(1).getStringCellValue();
				if (Faxpermission.equals("YES")) {

					String FaxAction = DpFaxInbox.getRow(1).getCell(0).getStringCellValue();

					Thread.sleep(2000);
					try {

						String FaxInboxHomeHTML = OrFaxInbox.getRow(1).getCell(3).getStringCellValue();
						String Organization = OrFaxInbox.getRow(2).getCell(4).getStringCellValue();
						String KSclientSearchvalue = OrFaxInbox.getRow(3).getCell(3).getStringCellValue();
						String KSclientselect = OrFaxInbox.getRow(4).getCell(3).getStringCellValue();
						String FaxStatuselement = OrFaxInbox.getRow(5).getCell(4).getStringCellValue();
						String Searchclick = OrFaxInbox.getRow(6).getCell(5).getStringCellValue();
						String FaxViewClick = OrFaxInbox.getRow(7).getCell(3).getStringCellValue();
						String TagElement = OrFaxInbox.getRow(8).getCell(3).getStringCellValue();
						String AssignFax = OrFaxInbox.getRow(10).getCell(3).getStringCellValue();
						String Patientsearch = OrFaxInbox.getRow(11).getCell(3).getStringCellValue();
						String PatientIDElement = OrFaxInbox.getRow(12).getCell(4).getStringCellValue();
						String SearchPatientClick = OrFaxInbox.getRow(13).getCell(5).getStringCellValue();
						String PatientSelected = OrFaxInbox.getRow(14).getCell(5).getStringCellValue();
						String CallerType = OrFaxInbox.getRow(15).getCell(4).getStringCellValue();
						String NotesLog = OrFaxInbox.getRow(16).getCell(4).getStringCellValue();
						String assignclick = OrFaxInbox.getRow(17).getCell(4).getStringCellValue();

						String KSClientsearch = DpFaxInbox.getRow(1).getCell(1).getStringCellValue();
						String FaxStatus = DpFaxInbox.getRow(1).getCell(2).getStringCellValue();
						String PatientId = DpFaxInbox.getRow(1).getCell(3).getStringCellValue();
						String CallerValue = DpFaxInbox.getRow(1).getCell(4).getStringCellValue();
						String Lognotesvalue = DpFaxInbox.getRow(1).getCell(5).getStringCellValue();

//							wait.until(ExpectedConditions
//									.elementToBeClickable(By.xpath(FaxInboxHomeHTML)));

						WebElement FaxInbox = driver.findElement(By.xpath(FaxInboxHomeHTML));
						FaxInbox.click();

						Thread.sleep(2000);

						String Loginpermission = DpModulePermission.getRow(2).getCell(1).getStringCellValue();

						if (Loginpermission.equals("KS")) {
							Thread.sleep(2000);
							WebElement Ksclientdopdown = driver.findElement(By.id(Organization));
							Ksclientdopdown.click();
							Thread.sleep(2000);

							WebElement KSSearch = driver.findElement(By.xpath(KSclientSearchvalue));
							KSSearch.sendKeys(KSClientsearch);

							Thread.sleep(2000);

							WebElement KSclientselectvalue = driver.findElement(By.xpath(KSclientselect));
							KSclientselectvalue.click();

						}

						Thread.sleep(2000);
						Select FaxinboxStatus = new Select(driver.findElement(By.id(FaxStatuselement)));
						FaxinboxStatus.selectByVisibleText(FaxStatus);

						WebElement FaxSearch = driver.findElement(By.name(Searchclick));
						Thread.sleep(2000);
						FaxSearch.click();
						
						Thread.sleep(2000);

						if (FaxAction.equals("VIEW") || FaxAction.equals("ASSIGN")) {
							

							WebElement PharmacyTitleView = driver.findElement(
									By.xpath("//*[@id='listGridDiv']/div[1]/table/tbody/tr[1]/td[8]/a[1]/img"));
							((JavascriptExecutor) driver)
							.executeScript("window.scrollTo(0," + PharmacyTitleView.getLocation().y + ")");
							if (PharmacyTitleView.getAttribute("title").equalsIgnoreCase("View")) {

								WebElement FaxViews = driver.findElement(By.xpath(FaxViewClick));
								((JavascriptExecutor) driver)
								.executeScript("window.scrollTo(0," + FaxViews.getLocation().y + ")");
								FaxViews.click();

								String current = driver.getWindowHandle();

								for (String handle1 : driver.getWindowHandles()) {

									driver.switchTo().window(handle1);

								}

								WebDriverWait wait1 = new WebDriverWait(driver, 20);
								try {
									Thread.sleep(3000);
								} catch (InterruptedException e1) {
									// TODO Auto-generated catch block
									e1.printStackTrace();
								}

								wait1.until(ExpectedConditions.presenceOfElementLocated(By.xpath(TagElement)));
								try {
									Thread.sleep(3000);
								} catch (InterruptedException e1) {
									// TODO Auto-generated catch block
									e1.printStackTrace();
								}

								try {
									Thread.sleep(300);
								} catch (InterruptedException e2) {
									// TODO Auto-generated catch block
									e2.printStackTrace();
								}

								WebElement TagClick = driver.findElement(By.xpath(TagElement));
								Thread.sleep(2000);
								((JavascriptExecutor) driver)
										.executeScript("window.scrollTo(0," + TagClick.getLocation().y + ")");
								TagClick.click();

								try {
									Thread.sleep(4000);
								} catch (InterruptedException e1) {
									// TODO Auto-generated catch block
									e1.printStackTrace();
								}
								driver.switchTo().window(current);

								WebElement AssignFaxClick = driver.findElement(By.xpath(AssignFax));
								((JavascriptExecutor) driver)
								.executeScript("window.scrollTo(0," + AssignFaxClick.getLocation().y + ")");
								AssignFaxClick.click();
								Thread.sleep(4000);
								for (String handle1 : driver.getWindowHandles()) {

									driver.switchTo().window(handle1);

								}

								WebDriverWait wait2 = new WebDriverWait(driver, 20);
								try {
									Thread.sleep(2000);
								} catch (InterruptedException e1) {
									// TODO Auto-generated catch block
									e1.printStackTrace();
								}

								wait2.until(ExpectedConditions.presenceOfElementLocated(By.xpath(Patientsearch)));
								try {

									Thread.sleep(2000);
								} catch (InterruptedException e1) {
									// TODO Auto-generated catch block
									e1.printStackTrace();
								}

								try {
									Thread.sleep(500);
								} catch (InterruptedException e2) {
									// TODO Auto-generated catch block
									e2.printStackTrace();
								}

								String winHandleBefore = driver.getWindowHandle();
								WebElement searchpatient = driver.findElement(By.xpath(Patientsearch));
								searchpatient.click();

								for (String handle1 : driver.getWindowHandles()) {

									driver.switchTo().window(handle1);

								}

								WebElement patientid = driver.findElement(By.id(PatientIDElement));
								patientid.sendKeys(PatientId);

								WebElement ClickSearchPatient = driver.findElement(By.name(SearchPatientClick));
								ClickSearchPatient.click();

								WebElement SelectPatient = driver.findElement(By.name(PatientSelected));
								((JavascriptExecutor) driver)
										.executeScript("window.scrollTo(0," + SelectPatient.getLocation().y + ")");

								try {
									Thread.sleep(500);
								} catch (InterruptedException e2) {
									// TODO Auto-generated catch block
									e2.printStackTrace();
								}

								WebElement SelectedPatient = driver.findElement(By.name(PatientSelected));
								SelectedPatient.click();

								driver.switchTo().window(winHandleBefore);

								try {
									Thread.sleep(500);
								} catch (InterruptedException e2) {
									// TODO Auto-generated catch block
									e2.printStackTrace();
								}

								Select CallertypeValue = new Select(driver.findElement(By.id(CallerType)));
								CallertypeValue.selectByVisibleText(CallerValue);

								WebElement LogNotes = driver.findElement(By.id(NotesLog));
								LogNotes.sendKeys(Lognotesvalue);

								WebElement assignbutton = driver.findElement(By.id(assignclick));
								((JavascriptExecutor) driver)
								.executeScript("window.scrollTo(0," + assignbutton.getLocation().y + ")");

								assignbutton.click();

							} else {

								WebElement AssignFaxClick = driver.findElement(By.xpath(AssignFax));
								((JavascriptExecutor) driver)
								.executeScript("window.scrollTo(0," + AssignFaxClick.getLocation().y + ")");

								AssignFaxClick.click();

								for (String handle1 : driver.getWindowHandles()) {

									driver.switchTo().window(handle1);

								}

								WebDriverWait wait1 = new WebDriverWait(driver, 20);
								try {
									Thread.sleep(2000);
								} catch (InterruptedException e1) {
									// TODO Auto-generated catch block
									e1.printStackTrace();
								}

								wait1.until(ExpectedConditions.presenceOfElementLocated(By.xpath(Patientsearch)));
								try {

									Thread.sleep(2000);
								} catch (InterruptedException e1) {
									// TODO Auto-generated catch block
									e1.printStackTrace();
								}

								try {
									Thread.sleep(500);
								} catch (InterruptedException e2) {
									// TODO Auto-generated catch block
									e2.printStackTrace();
								}

								String winHandleBefore = driver.getWindowHandle();
								WebElement searchpatient = driver.findElement(By.xpath(Patientsearch));
								searchpatient.click();

								for (String handle1 : driver.getWindowHandles()) {

									driver.switchTo().window(handle1);

								}

								WebElement patientid = driver.findElement(By.id(PatientIDElement));
								((JavascriptExecutor) driver)
								.executeScript("window.scrollTo(0," + patientid.getLocation().y + ")");

								patientid.sendKeys(PatientId);

								WebElement ClickSearchPatient = driver.findElement(By.name(SearchPatientClick));
								ClickSearchPatient.click();

								WebElement SelectPatient = driver.findElement(By.name(PatientSelected));
								((JavascriptExecutor) driver)
										.executeScript("window.scrollTo(0," + SelectPatient.getLocation().y + ")");

								try {
									Thread.sleep(500);
								} catch (InterruptedException e2) {
									// TODO Auto-generated catch block
									e2.printStackTrace();
								}

								WebElement SelectedPatient = driver.findElement(By.name(PatientSelected));
								SelectedPatient.click();

								driver.switchTo().window(winHandleBefore);

								try {
									Thread.sleep(500);
								} catch (InterruptedException e2) {
									// TODO Auto-generated catch block
									e2.printStackTrace();
								}

								Select CallertypeValue = new Select(driver.findElement(By.id(CallerType)));
								CallertypeValue.selectByVisibleText(CallerValue);

								WebElement LogNotes = driver.findElement(By.id(NotesLog));
								LogNotes.sendKeys(Lognotesvalue);

								WebElement assignbutton = driver.findElement(By.id(assignclick));
								((JavascriptExecutor) driver).executeScript("window.scrollTo(0," + assignbutton.getLocation().y + ")");
								
								assignbutton.click();

								System.out.println("Fax is assign to Patient Successfully.");
								test.log(LogStatus.INFO, "Fax is assign to Patient Successfully.");
							}

						}
					} catch (Exception e) {
						// TODO: handle exception
						System.out.println(e.getMessage());
					}

				}
				System.out.println("Fax is assign to Patient Successfully.");
				test.log(LogStatus.INFO, "Fax is assign to Patient Successfully");

			} else {
				// Patient Permission is no than come here
				System.out.println("Fax Permission is NO");
				test.log(LogStatus.INFO, "Fax Permission is NO");
			}

		} catch (Exception e) {
			// TODO: handle exception
			e.getMessage();

		}
	}
//		
//	@Test(priority = 13)
//	public void Telecome() throws InterruptedException {
//
//		Thread.sleep(4000);
//
//		WebDriverWait wait = new WebDriverWait(driver, 15);
//		wait.until(
//				ExpectedConditions.elementToBeClickable(driver.findElement(By.xpath("//*[@id='sidebar']/ul/li[4]/a"))));
//
//		String HomePageTitle = driver.getTitle();
//		if (HomePageTitle.equals("KloudScript")) { // Check the Page title if we are reach at home page or not.
//			// System.out.println("Ctuser"+CTUser);
//
//			String Faxpermission = DpModulePermission.getRow(11).getCell(1).getStringCellValue();
//			if (Faxpermission.equals("YES")) {
//
//				WebElement sidebarClick = driver.findElement(By.xpath("//*[@id=\'sidebar\']/ul/li[4]/a"));
//				sidebarClick.click();
//
//				WebElement telecomeclick = driver.findElement(By.xpath("//*[@id=\'menu4\']/ul/li[1]/a[2]"));
//				telecomeclick.click();
//
//				WebElement managefaxnumber = driver.findElement(By.xpath("/html/body/section/div[1]/ul/li/a/h2"));
//				managefaxnumber.click();
//
//				WebElement AddFaxCredential = driver.findElement(By.xpath("/html/body/section/section[2]/a"));
//				AddFaxCredential.click();
//
//				Thread.sleep(2000);
//
//				Select Organization = new Select(driver.findElement(By.xpath("//*[@id=\'organizationId\']")));
//				Organization.selectByVisibleText("KSCLIENT3");
//
//				Thread.sleep(2000);
//
//				WebElement ApiFaxNumber = driver.findElement(By.id("sFaxApiCredentialList0_apiFaxNumber"));
//				ApiFaxNumber.clear();
//				ApiFaxNumber.sendKeys("888-977-1665");
//
//				WebElement Apikey = driver.findElement(By.id("sFaxApiCredentialList0_apiKey"));
//				Apikey.clear();
//				Apikey.sendKeys("2A61E9D9F5B84779A1FC387075A0B534");
//
//				Thread.sleep(2000);
//
//				WebElement EncryptionKey = driver.findElement(By.id("sFaxApiCredentialList0_encryptionKey"));
//				EncryptionKey.clear();
//				EncryptionKey.sendKeys("i!v*W5p$WBciTp9Lnr@z_*&nbI$amsJM");
//
//				Thread.sleep(2000);
//
//				WebElement InitVector = driver.findElement(By.id("sFaxApiCredentialList0_initVector"));
//				InitVector.clear();
//				InitVector.sendKeys("x49e*wJVXr8BrALE");
//
//				WebElement UserName = driver.findElement(By.id("sFaxApiCredentialList0_userName"));
//				UserName.clear();
//				UserName.sendKeys("8889771665api");
//
//				Thread.sleep(2000);
//
//				WebElement HeaderNumber = driver.findElement(By.id("headerFaxNumberAdd"));
//				HeaderNumber.clear();
//				HeaderNumber.click();
//
//				Thread.sleep(2000);
//				WebElement FaxHeader = driver.findElement(By.id("faxCoverNumberList0_faxCoverNumber"));
//				FaxHeader.clear();
//				FaxHeader.sendKeys("8889771665");
//
//				WebElement HeaderSave = driver.findElement(By.id("saveNumberBtn"));
//				HeaderSave.click();
//
//				Thread.sleep(2000);
//
//				WebElement Save = driver.findElement(By.name("_action_save"));
//				Save.click();
//
//				Thread.sleep(2000);
//				System.out.println(driver.findElement(By.xpath("/html/body/section/div[1]")));
//				Assert.assertEquals(driver.findElement(By.xpath("/html/body/section/div[1]")).getText(),
//						"Record created successfully.");
//
//			}
//		}
//	}

	@AfterTest
	public void afterTest() {
		// driver.quit();
		/*
		 * reporter.endTest(test); reporter.flush();
		 */
		report.endTest(test);
		report.flush();
	}

	@BeforeTest
	public void beforeTest() {

		String exePath = "D:\\Neelam_Automation_Work\\project\\5-08-2020\\kloudscript-ondemand-sanity-testng-99bdd1472d7a\\drivers\\chromedriver.exe";
		System.setProperty("webdriver.chrome.driver", exePath);
		driver = new ChromeDriver();
		driver.manage().window().maximize();

	}

	public static WebElement getExactListOfElements(WebDriver p_driver, WebElement by, String itemToFound) {
		java.util.List<WebElement> mlist = by.findElements(By.tagName("li"));

		WebElement eleToFound = null;
	//	System.out.println("getExactListOfElements() itemToFound: " + itemToFound);
		for (WebElement webElement : mlist) {
			String itemName = webElement.getText();
			//System.out.println("getExactListOfElements() itemName is : " + itemName);
			if (itemName.trim().equalsIgnoreCase(itemToFound)) {

				eleToFound = webElement;

				break;
			}

		}

		return eleToFound;

	}
}
